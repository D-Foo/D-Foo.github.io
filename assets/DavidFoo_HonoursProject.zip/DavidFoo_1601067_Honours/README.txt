--Run the executable in exe folder--

It will ouput procedurally generated example spells
After it will output the sets it is parsing from the Data folder
After it will output which keywords are primary, secondary or tertiary for each colour
After it will output The cost of a point of power for each colour (the cost of a point of toughness is 4.5)
After it will output which keywords are primary, secondary or tertiary for each subtype of craeture
After it will output the cards created by the set.
The cards are also saved to the PROCGEN.xml file

Cards called SkelCard_X are staple cards that will be generated in every set