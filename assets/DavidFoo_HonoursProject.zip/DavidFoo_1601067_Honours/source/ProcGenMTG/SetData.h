#pragma once
#include <map>
#include <string>
#include <iostream>
#include "MTG_Structures.hpp"
#include "Tally_Structures.hpp"

using std::cout;
using std::cerr;

//Stores data and metrics about a set and performs analytical operations on it
class SetData
{
public:

	//Functions
	SetData();
	~SetData();

	void addKeyword(std::string keyword, bool W, bool U, bool B, bool R, bool G, MTGStruct::Rarity rarity, std::string creatureSubtype);
	void addSubtypes(std::string primarySubtype, std::vector<std::string> secondarySubtypes, bool W, bool U, bool B, bool R, bool G, MTGStruct::Rarity rarity);
	void addColourIdentity(MTGStruct::ColourIdentity ci);
	void outputKeywordTallyData();
	void createKeywordColourWeights();
	SetData combineWithSet(SetData* set2);	//Combines this sets data with another set and returns it

	//Setters + Getters
	void setSetName(std::string name) { setName = name; };
	std::string getSetName() { return setName; };
	void setSetSize(int size) { setSize = size; };
	int getSetSize() { return setSize; };	
	const std::map<std::string, TallyStruct::CombinedTally>* getKeywordTally() { return &keywordTally; };
	const std::map<std::string, TallyStruct::SubTypeData>* getSubtypeTally() { return &subtypeTally; };
	std::map <std::string, std::map<std::string, int>>* getSubtypeKeywordTally() { return &subtypeKeywordTally; };
	std::vector<std::string> getKeywords();

private:
	//Variables
	std::string setName;
	int setSize;
	float thresholdPercentages[3] = {12.5, 25, 50};	//Percentage appearance rate required to reach tertiary, secondary, primary.
	int minimumSampleSize = 5;	//Minmum sample size required to check for thresholds

	//Tallys
	std::map <std::string, TallyStruct::CombinedTally> keywordTally;	//Stores all keywords in the set and what colours they show up in
	std::map <std::string, TallyStruct::SubTypeData> subtypeTally;		//Stores all subtypes in the set and what colours they show up in
	std::map <std::string, std::map<std::string, int>> subtypeKeywordTally;	//Tracks keywords on each subtype
	int colourIdentityTally[MTGStruct::numColourIdentities];			//Stores number of times each colourIdentity shows up in the set


};

