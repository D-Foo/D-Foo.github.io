#pragma once
#include "SetSearcher.h"
#include <map>
#include <algorithm>

class PointBasedCalculator
{
public:
	PointBasedCalculator();
	~PointBasedCalculator();

	void run();
	void setVanillaCards(std::vector<MTGStruct::Card>* cards);
	void setKeywordCards(std::vector<MTGStruct::Card>* cards);
	void setCardTextCards(std::vector<std::pair<MTGStruct::Card, std::string>>* cardsAndCardText);
	int getPointsPerManaCost();

	//Used in Set + Card Creation 
	struct PointData
	{
		float pointsPerManaCost;
		float toughnessPointCost[5];
		float powerPointCost[5];
		float rarityPointMult[4];
		std::map<std::string, float> keywordCosts;
	};
	PointData getPointData();
	float getPTRatio(MTGStruct::ColourIdentity colour);
	std::array<std::vector<std::tuple<std::string, float, MTGStruct::Rarity, int>>, 5> getCardTexts() { return cardTexts; }	//Vector sorted by WUBRG, tuple<card effect, estimated point cost, rarity, CMC>

private:
	
	std::vector<MTGStruct::Card>* vanillaCards;
	std::vector<MTGStruct::Card>* keywordCards;
	std::vector<std::pair<MTGStruct::Card, std::string>>* cardTextCards;
	void calculatePowerToughnessData();
	void calculatePowerPointCost();
	void calculateKeywordCost();
	void calculateFollowOnTextCardsPointCost();

	struct PowerToughnessData
	{
		float averagePower;
		float averageToughness;
		float ratio;	//Power/Toughness Ratio
		std::pair<float, float>averagePTForManaCost[MTGStruct::manaCostCap + 1];	//Remembers the average power and toughness for each mana cost // (-1.0f, -1.0f) if no data available
		std::pair<int, int> modalPTForManaCost[MTGStruct::manaCostCap + 1];		//Remembers the most common power and toughness for each mana cost // (-1.0f, -1.0f) if no data available
	};

	
	
	PowerToughnessData data[6]; // W U B R G C

	const int pointsPerManaCost = 10;
	const float toughnessPointCost = 4.5f;//pointsPerManaCost / (4.0f / 1.0f);	// points / average toughness of 0/X 1 cost vanilla creatures
	float powerPointCost[5];//The cost of a point of power for each colour WUBRG
	std::map<std::string, float> keywordCosts;
	std::map<std::string, float> cardTextCosts;
	std::array<std::vector<std::tuple<std::string, float, MTGStruct::Rarity, int>>, 5> cardTexts;
};

