#pragma once
#include "MTG_Structures.hpp"
#include <vector>
#include <map>
#include <tuple>

class SetSearcher
{
public:

	SetSearcher();
	~SetSearcher();

	static std::vector<MTGStruct::Card> getVanillaCreatures(std::vector<MTGStruct::Card>& cards);	//Returns creatures with no cardText
	static std::vector<MTGStruct::Card> filterByColourIdentity(std::vector<MTGStruct::Card>& cards, MTGStruct::ColourIdentity colour);	//Returns creatures with no cardText
	static std::vector<MTGStruct::Card> filterToCreatures(std::vector<MTGStruct::Card>& cards);	//Filters to only creatures
	static std::vector<MTGStruct::Card> filterOutCreatures(std::vector<MTGStruct::Card>& cards);	//Filters out creatures from the vector
	static std::vector<MTGStruct::Card> filterByNumKeywords(std::vector<MTGStruct::Card>& cards, size_t numKeywords); //Filters to cards with a given number of keywords
	static std::vector<MTGStruct::Card> filterToKeywordOnly(std::vector<MTGStruct::Card>& cards);	//Filters to cards that only have their keyword(s) in their textbox
	static std::vector<MTGStruct::Card> filterToTargetPower(std::vector<MTGStruct::Card>& cards, int powerTarget);	//Filters to cards have a specific power
	static std::vector<MTGStruct::Card> filterByCardText(std::vector<MTGStruct::Card>& cards, std::string str, bool exclusive, bool inverse = false);	//Filters to cards with a specific string in their textbox, exclusive if no other card text should appear, inverse if cards with the card text should be filtered OUT
	static std::vector<MTGStruct::Card> filterToEquipment(std::vector<MTGStruct::Card>& cards);	//Filters to artifacts that equip (Equip {X})
	static std::vector<MTGStruct::Card> filterToActivatedArtifacts(std::vector<MTGStruct::Card>& cards);	//Activated {X}: Mana Cost == X, Tap == {T}:
	static std::vector<MTGStruct::Card> filterToPassiveArtifacts(std::vector<MTGStruct::Card>& cards);	//Filters to artifacts that equip (Equip {X})
																								


	static std::vector<std::tuple<std::string, int, MTGStruct::ColourIdentity>> getFollowOnTextToString(std::vector<MTGStruct::Card>& cards, std::string str);	//Returns the card text that follows after the given string
																																								//Returns <followOnText, number of times found, colour identity of card>
	static  std::vector<std::pair<MTGStruct::Card, std::string>> filterByLeadInText(std::vector<MTGStruct::Card>& cards, std::string str, std::array<std::string, MTGStruct::numKeywords> keywords);


private:

	static int searchCardTextForStr(std::string strToSearchFor, std::string cardText, std::string cardName);	//Returns the index the card text was found at, returns 0 if not found
	static std::pair<bool, std::string> compareStr(std::string str1, std::string str2, std::string cardName);
	static std::vector<std::string> strToVec(std::string str);
};

