#include "SetCreator.h"

SetCreator::SetCreator()
{
}

SetCreator::~SetCreator()
{
}

void SetCreator::setPointData(PointBasedCalculator::PointData pData)
{
	pointData = pData;
}

std::vector<MTGStruct::Card> SetCreator::createSet(SetCreator::SetParams params, SetData* setData)
{
	cardCreator.SetSetData(setData);

	bool outputSubtypeData = true;

	if (outputSubtypeData)
	{
		for (auto& st : *setData->getSubtypeTally())
		{
			int totalNumTimesSeen = st.second.numberTimesSeen;

			const int numThresholdTiers = 3;
			const int thresholdValues[numThresholdTiers] = { 75, 50, 25 };

			if (setData->getSubtypeKeywordTally()->find(st.first) != setData->getSubtypeKeywordTally()->end())
			{
				for (auto& kwT : setData->getSubtypeKeywordTally()->find(st.first)->second)
				{
					for (int i = 0; i < numThresholdTiers; ++i)
					{
						if ((static_cast<float>(kwT.second) / static_cast<float>(totalNumTimesSeen)) * 100.0f > thresholdValues[i])
						{
							bool kwFound = false;

							//Check potential keywords for data on linked keywords
							for (size_t j = 0; j < params.keywordTally.size(); ++j)
							{
								if (params.keywordTally.find(kwT.first) != params.keywordTally.end())
								{
									kwFound = true;
									break;
								}
							}
							if (kwFound)	//If data for this keyword was found
							{
								//DO THIS BEOFRE POINTS ARE ADDED
								switch (i)
								{
								case 0: //Primary(Add it)
								{
									cout << kwT.first << " is Primary for " << st.first << ". Sample Size: " << st.second.numberTimesSeen << "\n";
									break;
								}

								case 1: //Secondary(50% Chance to add)
								{
									cout << kwT.first << " is Secondary for " << st.first << ". Sample Size: " << st.second.numberTimesSeen << "\n";
									break;
								}
								case 2: //Tertiary(25% Chance to add)
								{
									cout << kwT.first << " is Tertiary for " << st.first << ". Sample Size: " << st.second.numberTimesSeen << "\n";
									break;
								}
								default:
#ifdef _DEBUG
									cerr << "Error: Hit default in switch statement: i == " << i << ". " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG				
									break;
								}
								break;
							}
						}
					}
				}
			}
		}
	}


	std::vector<MTGStruct::Card> ret;

	MTGStruct::ColourIdentity colourTable[6] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U, MTGStruct::ColourIdentity::B , MTGStruct::ColourIdentity::R, MTGStruct::ColourIdentity::G, MTGStruct::ColourIdentity::Colourless };

	int numCardsToMake[6][5] = { 0 };	//numCardsToMake[colour][0 = total, 1 = common, 2 = uncommon, 3 = rare, 4 = mythic)
	int numCardsToMakePerCMC[6][8] = { 0 };
	
	std::array<std::array<std::array<std::vector<std::pair<std::string, float>>, MTGStruct::manaCostCap>, 4>, 5> cardEffectsByCMCRarityColour;	//Stores cardEffectsBy CMC Rarity and Colour pair<card effect, point cost>
	std::array<std::array<std::vector<std::pair<std::string, float>>, MTGStruct::numRarities>, 5> colourKeywords;	//Stores keywords for each colour
	int effectCMCVariation = 2; // +/- 1 CMC allowed when dealing available card effects
	//Create card effect list for each CMC Colour and Rarity

	//For each colour
	for (int i = 0; i < 5; ++i)
	{
		//For each card effect in that colour
		for (auto& ce : params.cardTexts[i])
		{
			//Get it's rarity and CMC
			int CMC = std::get<3>(ce);
			MTGStruct::Rarity rarity = std::get<2>(ce);

			std::pair<std::string, float> effectAndCost = std::pair<std::string, float>(std::get<0>(ce), std::get<1>(ce));

			//Assign it in container
			cardEffectsByCMCRarityColour[i][static_cast<int>(rarity)][CMC].push_back(effectAndCost);
		}
	}

	//Create subtype list for each colour
	std::map<std::string, TallyStruct::SubTypeData> subtypes = *setData->getSubtypeTally();
	std::array<std::array<std::vector<std::pair<std::string, TallyStruct::SubTypeData>>, 4>, 5> colourSubtypes;
	for (auto& st : subtypes)
	{
		for (int j = 0; j < 5; ++j)
		{
			if (st.second.ct.colours[j].first > 0)	//Check if this subtype has showed up in this colour
			{
				for (int k = 0; k < MTGStruct::numRarities; ++k)
				{
					//Check each rarity this subtype has showed up in
					if (st.second.ct.colours[j].second.tally[k] > 0)
					{
						colourSubtypes[j][k].push_back(st);
					}
				}
			}
		}
	}

	//Calc num cards to make
	for (int i = 0; i < 5; ++i)
	{
		//Calculate total num cards to make for that colour
		numCardsToMake[i][0] = static_cast<float>(params.numCards) * (static_cast<float>(params.colourDistribution[i] / 100.0f));

		//Calculate num cards to make for that colour distributed by rarity
		for (int j = 0; j < 4; ++j)
		{
			numCardsToMake[i][j + 1] = (static_cast<float>(numCardsToMake[i][0])) * static_cast<float>(params.rarityDistribution[j]);
		}

		//Create keyword list for this colour + rarity
		for (auto& kw : params.keywordTally)
		{
			//Check if keyword showed up in this colour
			if (kw.second.colours[i].first != 0)
			{
				std::pair<std::string, float> colourKw;
				colourKw.first = kw.first;
				//Get it's cost
				if (params.keywordCosts.find(colourKw.first) != params.keywordCosts.end())
				{
					colourKw.second = params.keywordCosts.find(colourKw.first)->second;
					//Check the lowest rarity this colour appeared at
					int rarityNum = 0;
					bool rarityFound = false;
					for (int j = 0; j < 4; ++j)
					{
						if (kw.second.colours->second.tally[j] > 0)
						{
							rarityFound = true;
							rarityNum = j;
							break;
						}
					}
					//Store in the appropriate rarity section of the colour keyword array
					if (rarityFound)
					{
						colourKeywords[i][rarityNum].push_back(colourKw);
					}
				}

			}
		}

		//Calc number cards to make per CMC

		int numCardsToMakePerCMCSum = 0;
		for (int j = 0; j < 8; ++j)
		{
			numCardsToMakePerCMC[i][j] = (static_cast<float>(params.manaCostDistribution[j]) / 100.0f) * numCardsToMake[i][0];
			numCardsToMakePerCMCSum += numCardsToMakePerCMC[i][j];
		}
		//Check if less cards were made due to flooring for CMC
		if (numCardsToMakePerCMCSum < numCardsToMake[i][0])
		{
			//Randomly assign more cards to be created to make up the difference
			for (int j = 0; j < numCardsToMake[i][0] - numCardsToMakePerCMCSum; ++j)
			{
				int randCMC = rand() % 7 + 1;
				++numCardsToMakePerCMC[i][randCMC];
			}
		}

		//Check if less cards were made due to flooring for Rarity
		int numCardToMakeRaritySum = numCardsToMake[i][1] + numCardsToMake[i][2] + numCardsToMake[i][3] + numCardsToMake[i][4];
		if (numCardToMakeRaritySum < numCardsToMake[i][0])
		{
			//Randomly assign more cards to be created to make up the difference
			for (int j = 0; j < numCardsToMake[i][0] - numCardToMakeRaritySum; ++j)
			{
				float randRarity = rand() % 100 + 0;
				randRarity /= 100;
				int index = 0;
				bool indexChosen = false;
				float chanceSum = 0;
				for (int k = 0; k < 4; ++k)
				{
					chanceSum += params.rarityDistribution[k];
					if (randRarity <= chanceSum)
					{
						index = k;
						indexChosen = true;
						break;
					}
				}
				if (!indexChosen)
				{
					index = MTGStruct::numRarities - 1;
				}
				++numCardsToMake[i][index + 1];
			}
		}

#ifdef _DEBUG
		else if (numCardsToMakePerCMCSum > numCardsToMake[i][0])
		{
			cerr << "Error: Making too many cards in " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
		}

		//Check rarites add up to total
		if (numCardsToMake[i][0] != numCardsToMake[i][1] + numCardsToMake[i][2] + numCardsToMake[i][3] + numCardsToMake[i][4])
		{
			cerr << "Error: Rarity sum (" << numCardsToMake[i][0] << ") not equal to parts {" << numCardsToMake[i][1] << ", " << numCardsToMake[i][2] << ", " << numCardsToMake[i][3] << ", " << numCardsToMake[i][4] << "} in " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
		}

#endif // _DEBUG

	}

	//Decrement numCardsToMake and numCardsToMakePerCMC for each skeleton
	int cSkelCount = 0;
	for (auto& cSkel : params.cardSkeletons)
	{
		++cSkelCount;
		int colourIndex = static_cast<int>(cSkel.cI) - 1;
		--numCardsToMake[colourIndex][static_cast<int>(cSkel.rarity)];
		--numCardsToMakePerCMC[colourIndex][MTGStruct::ManaCostToCMC(cSkel.manaCost)];

		//Create the card described by the skeleton
		CardCreator::CreatureParams cParams;
		cParams.numPoints = (params.pointsPerManaCost * cParams.CMC) + baseCardPoints;
		cParams.pointMultiplier = params.rarityPointMultiplier[static_cast<int>(cSkel.rarity)];
		cParams.name = "SkelCard_";
		cParams.name += std::to_string(cSkelCount);
		cParams.powerPointCost = params.powerPointCosts[colourIndex];
		cParams.toughnessPointCost = params.toughnessPointCosts[colourIndex];
		cParams.PT_Ratio = params.PTRatio[colourIndex];
		cParams.rarity = cSkel.rarity;
		cParams.colour = colourTable[colourIndex];
		std::vector<std::pair<std::string, float>> availableKeywords;
		for (int k = static_cast<int>(cSkel.rarity); k >= 0; --k)
		{
			for (auto& kw : colourKeywords[colourIndex][k])
			{
				bool kwFound = false;
				for (auto& kw2 : availableKeywords)
				{
					if (kw.first == kw2.first)
					{
						kwFound = true;
						break;
					}
				}
				if (!kwFound)
				{
					availableKeywords.push_back(kw);
				}
			}
		}
		cParams.potentialKeywords = availableKeywords;

		cParams.supertype = MTGStruct::Supertype::Creature;
		ret.push_back(cardCreator.FillInCardSkeleton(cSkel, cParams, params.pointsPerManaCost));
	}

	//Create the rest of the cards for each colour
	for(int i = 0; i < 5; ++i)
	{
		//Sum list to create card checkpoint nums
		for (int j = 7; j >= 0; --j)
		{
			int previousSum = 0;
			for (int k = j; k >= 0; --k)
			{
				previousSum += numCardsToMakePerCMC[i][k];
			}
			numCardsToMakePerCMC[i][j] = previousSum;
		}

		//Create Cards for this colour
		for (int j = 0; j < numCardsToMake[i][0]; ++j)
		{
			//Setup card paramaters
			CardCreator::CreatureParams cParams;
			cParams.colour = colourTable[i];
			for (int k = 0; k < 8; ++k)
			{
				if (j < numCardsToMakePerCMC[i][k])
				{
					cParams.CMC = k;
					break;
				}
			}
			MTGStruct::ManaCost mc;
			MTGStruct::ManaCostAddWUBRG(mc, colourTable[i], 1);
			cParams.CMC > 1 ? mc.generic = cParams.CMC - 1 :  mc.generic = 0;
			cParams.manaCost = mc;
			cParams.numPoints = (params.pointsPerManaCost * cParams.CMC) + baseCardPoints;
			if (cParams.CMC == 1)
			{
				cParams.numPoints += 5;
			}
			
			//Get available rarities then randomly choose one 
			std::vector<int> availableRarityIndices;
			for (int k = 0; k < 4; ++k)
			{
				if (numCardsToMake[i][k + 1] > 0)
				{
					availableRarityIndices.push_back(k + 1);
				}
			}

			int rarityIndex = rand() % static_cast<int>(availableRarityIndices.size());
			
			//Assign rarity
			--numCardsToMake[i][rarityIndex + 1];
			cParams.rarity = static_cast<MTGStruct::Rarity>(rarityIndex);	
			cParams.pointMultiplier = params.rarityPointMultiplier[static_cast<int>(cParams.rarity)];

			//Get all keywords of the rarity and below (giving commons uncommons as well for the sake of variety, wouldn't need to do this with more available effects)
			std::vector<std::pair<std::string, float>> availableKeywords;
			for (int k = static_cast<int>(cParams.rarity); k >= 0; --k)
			{
				for (auto& kw : colourKeywords[i][k])
				{
					bool kwFound = false;
					for (auto& kw2 : availableKeywords)
					{
						if (kw.first == kw2.first)
						{
							kwFound = true;
							break;
						}
					}
					if (!kwFound)
					{
						availableKeywords.push_back(kw);
					}
				}
			}
			cParams.potentialKeywords = availableKeywords;

			//Assign card effects	
			std::vector<std::pair<std::string, float>> allAvailableCardTexts;
			int minEffectCMC = cParams.CMC - effectCMCVariation;
			int maxEffectCMC = cParams.CMC + effectCMCVariation;
			if (minEffectCMC < 0)
			{
				minEffectCMC = 0;
			}
			if (maxEffectCMC >= MTGStruct::manaCostCap)
			{
				maxEffectCMC = MTGStruct::manaCostCap;
			}
			
			for (int k = minEffectCMC; k < maxEffectCMC; ++k)
			{
				for (auto& ce : cardEffectsByCMCRarityColour[i][static_cast<int>(cParams.rarity)][k])
				{
					allAvailableCardTexts.push_back(ce);
				}
			}

		



			cParams.potentialCardTexts = allAvailableCardTexts;

			cParams.powerPointCost = params.powerPointCosts[i];
			cParams.toughnessPointCost = params.toughnessPointCosts[i];
			cParams.PT_Ratio = params.PTRatio[i];
		
			cParams.supertype = MTGStruct::Supertype::Creature;
			
			cParams.name = "PROC_GEN_CARD_";
			int cardNum = 1;
			for (int k = 0; k < i; ++k)
			{
				cardNum += numCardsToMake[k][0];
			}
			cardNum += j;
			cParams.name += std::to_string(cardNum);
			cParams.potentialSubtypes = colourSubtypes[i][static_cast<int>(cParams.rarity)];
			Skeleton::CardSkeleton cSkeleton;
			cSkeleton.manaCost = cParams.manaCost;
			cSkeleton.supertype = MTGStruct::Supertype::Creature;

			//Roll vanilla / french vanilla chance
			int vanillaRoll = (rand() % 100) + 1; //Random number between 1 and 100
			if (vanillaRoll <= vanillaChance)
			{
				cSkeleton.isVanilla = true;
			}
			else if(vanillaRoll <= frenchVanillaChance)
			{
				cSkeleton.isFrenchVanilla = true;
			}

			ret.push_back(cardCreator.FillInCardSkeleton(cSkeleton, cParams, params.pointsPerManaCost));
		}
	}





	return ret;
}
