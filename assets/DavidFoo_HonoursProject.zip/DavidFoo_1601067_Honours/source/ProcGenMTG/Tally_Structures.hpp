#pragma once
#include <map>

namespace TallyStruct
{

	//Structs
	struct RarityTally
	{
		//tally[common, uncommon, rare, mythic]
		short unsigned int tally[4] = { 0 };
		void operator+= (RarityTally rt2)
		{
			tally[0] += rt2.tally[0];
			tally[1] += rt2.tally[1];
			tally[2] += rt2.tally[2];
			tally[3] += rt2.tally[3];
		}
	};

	struct CombinedTally
	{
		//colours [W, U, B, R, G, C]
		//pair<total tally, tally by rarity>
		std::pair<short unsigned int, RarityTally> colours[6]; // = { std::pair<short unsigned int, SetData::RarityTally>(0, SetData::RarityTally()) }; <-- This causes an internal compiler error :/
		void operator+= (CombinedTally ct2)
		{
			for (int i = 0; i < 6; ++i)
			{
				colours[i].first += ct2.colours[i].first;
				colours[i].second += ct2.colours[i].second;
			}
		}
	};
	struct SubTypeData
	{
		CombinedTally ct;	//Stores combined tally data for all primaries of this type
		std::map<std::vector<std::string>, CombinedTally> secondaries;	//Stores any additional subtypes e.g. Wizard, Werewolf etc. and what colours they show up in
		int numberTimesSeen;	//Stores the total number of times this subtype has showed up
		void operator+= (SubTypeData st2)
		{
			//Aggregate combined tallies
			ct += st2.ct;
			numberTimesSeen += st2.numberTimesSeen;
			//For each secondary subtype
			for (auto& st : st2.secondaries)
			{
				//Check if secondary subtype exists
				std::map<std::vector<std::string>, CombinedTally>::iterator it = secondaries.find(st.first);
				if (it == secondaries.end())
				{
					//If it doesn't add it and it's data
					secondaries.insert(st);
				}
				else
				{
					//Otherwise aggregate the combined tallies
					it->second += st.second;
				}
			}
		}
	};
	struct TallyTresholds
	{
		TallyTresholds() {}
		TallyTresholds(float primary, float secondary, float tertiary) { this->primary = primary, this->secondary = secondary, this->tertiary = tertiary; }
		//What percentage thresholds to class the keywords under
		float primary = 0.0f;
		float secondary = 0.0f;
		float tertiary = 0.0f;
	};
}