#pragma once


//Decides how many points a card should be assigned, how much keywords P/T and effects cost


class PointAllocator
{
};

