#include "CardCreator.h"

MTGStruct::Card CardCreator::FillInCardSkeleton(Skeleton::CardSkeleton cardSkeleton, CreatureParams params, int pointsPerManaCost)
{
	//Fill in Creatures
	if (cardSkeleton.supertype == MTGStruct::Supertype::Creature || cardSkeleton.supertype == MTGStruct::Supertype::ArtifactCreature)
	{
		return FillInCreatureSkeleton(cardSkeleton, params, pointsPerManaCost);
	}
	else
	{
		return MTGStruct::Card();
	}
}

MTGStruct::Card CardCreator::CreateSpell(SpellParams params)
{
	MTGStruct::ColourIdentity monoColours[5] = {MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U , MTGStruct::ColourIdentity::B, MTGStruct::ColourIdentity::R, MTGStruct::ColourIdentity::G};

	MTGStruct::Card ret;
	ret.colourIdentity = params.colour;
	ret.name = params.name;
	ret.rarity = params.rarity;

	//Check colour of spell to be created
	switch (params.colour)
	{
	case MTGStruct::ColourIdentity::W:
	{
		//White (Gain life + Optional Draw)
		const int CMCRange = 3;

		//Roll CMC
		int CMC = std::rand() % CMCRange; //0-2

		//Cost based on life (3 life -> 0 CMC, 6-> 1CMC, 10 - 2CMC)
		int lifeGen[CMCRange] = {3, 6, 10};

		

		//Roll instant + cantrip 
		bool instant = std::rand() % 2;
		bool cantrip = std::rand() % 2;

		std::string cardText = "You gain ";
		cardText.append(std::to_string(lifeGen[CMC]));
		cardText.append(" life.");

		//If both roll false roll one to be true at random
		if (!instant && !cantrip)
		{
			rand() % 2 ? instant = true : cantrip = true;
		}

		//Instant/Sorcery

		//Bump up cost 1 if instant
		if (instant)
		{
			CMC += 1;
			ret.supertype = MTGStruct::Supertype::Instant;
		}
		else
		{
			ret.supertype = MTGStruct::Supertype::Sorcery;
		}

		//Cantrip?
		if (cantrip)
		{
			CMC += 1; //Bump up cost 1

			//Add Card Text
			cardText.append("Draw a card.");
		}
			
		ret.manaCost.white = 1;
		ret.manaCost.generic = CMC - 1;
		ret.CMC = CMC;
		ret.cardText = cardText;

		break;
	}
	case MTGStruct::ColourIdentity::U:
	{
		//Blue (Divination etc.)
		
		const int CMCRange = 3;

		//Roll CMC
		int CMC = (std::rand() % CMCRange) + 3;//3-5

		//Roll cards to Draw (2 = 3 CMC), (3 = 4 CMC), (4 = 5 CMC)
		int numCardsToDraw[CMCRange] = { 2, 3, 4 };
		
		std::string cardText = "Draw ";
		cardText.append(std::to_string(numCardsToDraw[CMC - 3]));
		cardText.append(" cards.");

		//Roll Instant/Sorcery
		bool instant = std::rand() % 2;
		if (instant)
		{
			//Bump up cost 1 if instant
			CMC += 1;
			ret.supertype = MTGStruct::Supertype::Instant;
		}
		else
		{
			ret.supertype = MTGStruct::Supertype::Sorcery;
		}

		if (CMC >= 4)
		{
			ret.manaCost.blue = 2;
			ret.manaCost.generic = CMC - 2;
		}
		else
		{
			ret.manaCost.blue = 1;
			ret.manaCost.generic = CMC - 1;
		}
		ret.CMC = CMC;
		ret.cardText = cardText;

		break;
	}
	case MTGStruct::ColourIdentity::B:
	{
		//Black (Sign in Blood)
		const int CMCRange = 3;

		//Roll cards to Draw (2 = 2 CMC), (3 = 3 CMC), (4 = 4 CMC)
		int CMC = (std::rand() % CMCRange) + 2;//3-5

		int numCardsToDraw[CMCRange] = { 2, 3, 4 };

		//Lose life equal to number of drawn cards
		std::string cardText = "You Draw ";
		cardText.append(std::to_string(numCardsToDraw[CMC - 2]));
		cardText.append(" cards and you lose ");
		cardText.append(std::to_string(numCardsToDraw[CMC - 2]));
		cardText.append(" life.");


		//Roll Instant/Sorcery
		bool instant = std::rand() % 2;
		if (instant)
		{
			//Bump up cost 1 if instant
			CMC += 1;
			ret.supertype = MTGStruct::Supertype::Instant;
		}
		else
		{
			ret.supertype = MTGStruct::Supertype::Sorcery;
		}

		ret.manaCost.black = 1;
		ret.manaCost.generic = CMC - 1;
		ret.CMC = CMC;
		ret.cardText = cardText;

		break;
	}
	case MTGStruct::ColourIdentity::R:
	{
		//Red (Bolt Variation)
		const int CMCRange = 3;

		//Roll Damage (2 = 1 CMC), (3 = 2 CMC), (4 = 3 CMC)
		int CMC = (std::rand() % CMCRange) + 1;//1-3

		int damage[CMCRange] = { 2, 3, 4 };
		int cardDamage = damage[CMC - 1];

		//Roll Instant Sorcery

		bool instant = std::rand() % 2;
		if (instant)
		{
			ret.supertype = MTGStruct::Supertype::Instant;
		}
		else
		{
			ret.supertype = MTGStruct::Supertype::Sorcery;

			bool CMCReduction = rand() % 2;
			if (CMC == 1)
			{
				CMCReduction = false;
			}

			if (CMCReduction)
			{
				CMC -= 1;
			}
			else
			{
				cardDamage += 1;
			}
		}

		std::string cardText = ret.name;
		cardText.append(" deals ");
		cardText.append(std::to_string(cardDamage));
		cardText.append(" damage to any target.");
		
		if (CMC >= 4)
		{
			ret.manaCost.red = 2;
			ret.manaCost.generic = CMC - 2;
		}
		else
		{
			ret.manaCost.red = 1;
			ret.manaCost.generic = CMC - 1;
		}
		ret.CMC = CMC;
		ret.cardText = cardText;

		break;
	}
	case MTGStruct::ColourIdentity::G:
	{
		//Green (Pump Spell)
		const int CMCRange = 3;


		//Roll Pump (+2/+2 = 1 CMC), (+4/+4 = 2 CMC), (+6/+6 = 3CMC)
		int CMC = (std::rand() % CMCRange) + 2;//3-5

		int PUMP[CMCRange] = { 3, 5, 7 };
		int pumpValue = PUMP[CMC - 2];

		
	
		//Is Instant
		ret.supertype = MTGStruct::Supertype::Instant;

		//Roll Trample/Reach + Untap/Hexproof, -1/-1 if rolled
		bool extra = rand() % 2;
		std::string endOfTurnText = " until end of turn.";
		std::string extraCardText = "";
		bool untap = false;
		if (extra)
		{
			pumpValue -= 1;
			std::string possibleExtras[3] = {" and gains trample", " and gains hexproof", " and gains reach"};
			extra = rand() % 3;
			if (extra == 2)
			{
				untap = true;
			}
			extraCardText = possibleExtras[extra];
		}
		else
		{

		}
		std::string cardText = "Target creature gets +";
		cardText.append(std::to_string(pumpValue));
		cardText.append("/+");
		cardText.append(std::to_string(pumpValue));
		cardText.append(extraCardText);
		cardText.append(endOfTurnText);
		if (untap)
		{
			cardText.append(" Untap it.");
		}

		ret.manaCost.green = 1;
		ret.manaCost.generic = CMC - 1;
		ret.CMC = CMC;
		ret.cardText = cardText;

		break;
	}
	default:
#ifdef _DEBUG
		cerr << "Error: Hit default in switch Statement " << typeid(*this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG	
		break;
	}

	return ret;
}

MTGStruct::Card CardCreator::FillInCreatureSkeleton(Skeleton::CardSkeleton cardSkeleton, CreatureParams params, int pointsPerManaCost)
{
	//Check for pre assigned data
	//Use it to create more tailored card params for CardCreator to use to create card

	MTGStruct::Card ret;

	bool addKeywords = false;	//Track whether or not to add keywords later on in cardgen
	bool addCardText = false;	//Track whether or not to add card text later on in cardgen
	bool addSubtypes = false;	//Track whether or not to add card text later on in cardgen

	//Track whether card elements are preset by the skeleton
	bool setKeywords = false;
	bool setCardText = false;
	bool setPower = false;
	bool setToughness = false;
	bool setSubtypes = false;

	int sizeManaCostIndex = 0;

	//Creature Size
	if (cardSkeleton.creatureSize != Skeleton::CreatureSize::NotSet)
	{

		switch (cardSkeleton.creatureSize)
		{
		case Skeleton::CreatureSize::Small:
			break;

		case Skeleton::CreatureSize::Medium:
			sizeManaCostIndex = 1;
			break;

		case Skeleton::CreatureSize::Large:
			sizeManaCostIndex = 2;
			break;
		default:
#ifdef _DEBUG
			cerr << "Error hit default in CreatureSize switch in CardCreator::FillInCreatureSkeleton(), line " << __LINE__ << " file " << __FILE__  << "\n";
#endif // _DEBUG
			break;
		}

		//Assign CMC
		ret.CMC = Skeleton::manaCosts[sizeManaCostIndex][0] + rand() % (Skeleton::manaCosts[sizeManaCostIndex][1] - Skeleton::manaCosts[sizeManaCostIndex][0]);	//Random number between the first number of Skeleton::manaCosts at that size index and the second

		
		//Add mana cost based on colour
		ret.manaCost.generic = ret.CMC - 1;
		switch (params.colour)
		{
		case MTGStruct::ColourIdentity::W:
			ret.manaCost.white = 1;
			break;
		case MTGStruct::ColourIdentity::U:
			ret.manaCost.blue = 1;
			break;
		case MTGStruct::ColourIdentity::B:
			ret.manaCost.black = 1;
			break;
		case MTGStruct::ColourIdentity::R:
			ret.manaCost.red = 1;
			break;
		case MTGStruct::ColourIdentity::G:
			ret.manaCost.green = 1;
			break;
		case MTGStruct::ColourIdentity::Colourless:
			++ret.manaCost.generic;
			break;
		default:
			break;	
		}

	}
	else
	{
		if (cardSkeleton.manaCost != MTGStruct::ManaCostZero)
		{
			ret.manaCost = cardSkeleton.manaCost;
			ret.CMC = MTGStruct::ManaCostToCMC(ret.manaCost);

			//Get sizeManaCostIndex
			for (int i = 0; i < 3; ++i)
			{
				if (ret.CMC <= Skeleton::manaCosts[i][1])
				{
					sizeManaCostIndex = i;
					break;
				}
			}
		}
	}


	//Rarity 
	ret.rarity = params.rarity;
	ret.colourIdentity = params.colour;
	ret.name = params.name;
	ret.cardText = "";
	ret.supertype = params.supertype;


	float pipMultiplier = 1.0f;	//Todo Modify this (maybe a + instead of a multiplier)

	float numPoints = ret.CMC * pointsPerManaCost * params.pointMultiplier * pipMultiplier;	//Set numPoints based on cards CMC

	//Keywords
	if (!cardSkeleton.keywords.empty())
	{
		setKeywords = true;
	}
	else if(!cardSkeleton.isVanilla)
	{
		//If not vanilla
		addKeywords = true;
	}
	//Card Text
	if (!cardSkeleton.cardTextToAdd.empty())
	{
		setCardText = true;

		//Check if card text to add is whole sentence (back == '.')
		//Else check if matches a part of text chain library, complete chain to make whole sentence.
	} 
	else if(!cardSkeleton.isVanilla && !cardSkeleton.isFrenchVanilla)
	{
		//Generate creature text here
		addCardText = true;
	}

	

	//Power and Toughness
	if (cardSkeleton.power != 0)
	{
		setPower = true;
	}
	if (cardSkeleton.toughness != 0)
	{
		setToughness = true;
	}

	

	//Create card here
	//For each pre assigned part in params add it to card
	//Then work out cost of those points on card
	float setPointSum = 0.0f;

	if (setKeywords)
	{
		float kwSum = 0.0f;
		//Work out cost of KW and subtract num points
		for (auto& kw : cardSkeleton.keywords)
		{
			//Find keyword in 
			for (auto& paramKW : params.potentialKeywords)
			{
				if (kw == paramKW.first)
				{
					kwSum += paramKW.second;
					break;
				}
			}
			//Keyword not found
#ifdef _DEBUG
			cerr << "Error: Keyword not found in for loop in" << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG

		}
	}

	if (setCardText)
	{
		//Work out cost of card text and subtract num points
	}

	if (setPower)
	{
		setPointSum += cardSkeleton.power * params.powerPointCost;
		ret.power = cardSkeleton.power;
	}
	else
	{
		ret.power = 0;
	}

	if (setToughness)
	{
		setPointSum += cardSkeleton.toughness * params.toughnessPointCost;
		ret.toughness = cardSkeleton.toughness;
	}
	else
	{
		ret.toughness = 1;
	}

	if (!cardSkeleton.subtypes.empty())
	{
		setSubtypes = true;
	}
	else
	{
		addSubtypes = true;
	}

	if (addSubtypes)
	{
		//Roll subtype
		std::string primarySubtype;
		int primarySubtypeIndex = rand() % static_cast<int>(params.potentialSubtypes.size());
		primarySubtype = params.potentialSubtypes[primarySubtypeIndex].first;
		ret.subtypes.push_back(primarySubtype);
	}
	else
	{
		ret.subtypes = cardSkeleton.subtypes;
	}

	//Fill in remainder of card parts with remaining points
	float remainingPoints = numPoints - setPointSum;

	//Add card text
	if (addCardText)
	{
		//Pick random cardText
		if (!params.potentialCardTexts.empty())
		{
			int randCardTextID = rand() % static_cast<int>(params.potentialCardTexts.size());
			if (std::get<1>(params.potentialCardTexts[randCardTextID]) <= remainingPoints)
			{
				ret.cardText += std::get<0>(params.potentialCardTexts[randCardTextID]);
				remainingPoints -= std::get<1>(params.potentialCardTexts[randCardTextID]);
			}
		}
	}
	else
	{
		for (auto& str : cardSkeleton.cardTextToAdd)
		{
			ret.cardText += str;
			ret.cardText += "";
		}
	}

	if (addKeywords)
	{
		std::vector<int> chosenKeywordNums;//Stores the IDs of added keywords to prevent duplicate keywords being added

		//Roll Num Keywords To Add
		int numKeywordsToAdd = Skeleton::numKeywordsToAdd[sizeManaCostIndex][0] + rand() % (Skeleton::numKeywordsToAdd[sizeManaCostIndex][1] - Skeleton::numKeywordsToAdd[sizeManaCostIndex][0] + 1);	//Random number between the first number of Skeleton::numKeywordsToAdd at that index and the second

		//Check for subtype keyword linking (primary, secondary, tertiary)
		if (setData->getSubtypeKeywordTally()->find(ret.subtypes[0]) != setData->getSubtypeKeywordTally()->end())
		{
			//Data for this subtype found

			//Get number of times seen

			if (setData->getSubtypeTally()->find(ret.subtypes[0]) != setData->getSubtypeTally()->end())
			{
				int totalNumTimesSeen = setData->getSubtypeTally()->find(ret.subtypes[0])->second.numberTimesSeen;

				const int numThresholdTiers = 3;
				const int thresholdValues[numThresholdTiers] = { 75, 50, 25 };

				for (auto& kwT : setData->getSubtypeKeywordTally()->find(ret.subtypes[0])->second)
				{

					for (int i = 0; i < numThresholdTiers; ++i)
					{
						if ((static_cast<float>(kwT.second) / static_cast<float>(totalNumTimesSeen)) * 100.0f > thresholdValues[i])
						{
							int keywordNum = -1;
							
							//Check potential keywords for data on linked keywords
							for (size_t j = 0; j < params.potentialKeywords.size(); ++j)
							{
								if (kwT.first == params.potentialKeywords[j].first)
								{
									keywordNum = j;
									break;
								}
							}

							bool chosenBefore = false;

							for (auto& i : chosenKeywordNums)
							{
								if (keywordNum == i)
								{
									chosenBefore = true;
									break;
								}
							}

							if (keywordNum != -1 && !chosenBefore)	//If data for this keyword was found
							{
								//DO THIS BEOFRE POINTS ARE ADDED
								switch (i)
								{
								case 0: //Primary(Add it)
								{
									ret.cardText.append(kwT.first);
									ret.cardText.append(" ");

									remainingPoints -= params.potentialKeywords[keywordNum].second;
									chosenKeywordNums.push_back(keywordNum);
									--numKeywordsToAdd;

									//Spent more on linked keywords than points available so increase mana cost and add points to compensate
									if (remainingPoints < 0)
									{
										++ret.CMC;
										++ret.manaCost.generic;
										remainingPoints += 1 * pointsPerManaCost * params.pointMultiplier * pipMultiplier;
									}
									break;
								}

								case 1: //Secondary(50% Chance to add)
								{
									if (numKeywordsToAdd > 0)
									{
										bool addKeyword = !(rand() % 2); //1 in 2 chance

										if (addKeyword)
										{
											ret.cardText.append(kwT.first);
											ret.cardText.append(" ");

											remainingPoints -= params.potentialKeywords[keywordNum].second;
											chosenKeywordNums.push_back(keywordNum);
										}
									}
									break;
								}
								case 2: //Tertiary(25% Chance to add)
								{
									if (numKeywordsToAdd > 0)
									{
										bool addKeyword = !(rand() % 4); //1 in 4 chance

										if (addKeyword)
										{
											ret.cardText.append(kwT.first);
											ret.cardText.append(" ");

											remainingPoints -= params.potentialKeywords[keywordNum].second;
											chosenKeywordNums.push_back(keywordNum);
										}
									}
									break;
								}
								default:
#ifdef _DEBUG
									cerr << "Error: Hit default in switch statement: i == " << i <<". " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG		
									break;
								}
							}
						}
					}
				}


			}
		}

		//Roll random keyword(s) equal to num keywords
		//DUPLICATE CODE -> MOVE TO FUNCTION THAT RETURNS VECTOR OF STRINGS
		for (int i = 0; i < numKeywordsToAdd; ++i)
		{
			//Make sure KW hasn't been chosen already
			bool chosenBefore = false;
			int randKeywordNum = 0;
			
			do {
				chosenBefore = false;
				randKeywordNum = rand() % static_cast<int>(params.potentialKeywords.size());

				for (auto& num : chosenKeywordNums)
				{
					if (num == randKeywordNum)
					{
						chosenBefore = true;
					}
				}
			} while (chosenBefore && chosenKeywordNums.size() < params.potentialKeywords.size());

			//Apply keyword
			if (params.potentialKeywords[randKeywordNum].second < remainingPoints)
			{
				bool applyKeyword = true;
				//5% Chance to apply if it's a negative keyword (negative point cost)
				if (params.potentialKeywords[randKeywordNum].second < 0)
				{
					applyKeyword = false;
					int fivePercent = rand() % 20;
					if (!fivePercent)
					{
						applyKeyword = true;
					}
				}

				if (applyKeyword)
				{
					if (ret.cardText != "")
					{
						ret.cardText.append(" ");
					}
					ret.cardText.append(params.potentialKeywords[randKeywordNum].first);
					
					remainingPoints -= params.potentialKeywords[randKeywordNum].second;
					chosenKeywordNums.push_back(randKeywordNum);
				}
			}
			else
			{
				break;
			}
		}
	}
	else
	{
		for (auto& str : cardSkeleton.keywords)
		{
			ret.cardText += str;
			ret.cardText += " ";
		}
	}

	//Apply leftover points to P + T roughly adhering to PT ratio
	//Could include random amounts of boosting power over toughness etc.
	//DUPLICATE CODE -> MOVE TO FUNCTION THAT RETURNS PAIR OF INTS
	if (!setPower && !setToughness)
	{
		do
		{
			bool powerPreferred = false;
			//Get card ratio and check whether toughness or power should go up
			float currentCardPTRatio = static_cast<float>(ret.power) / static_cast<float>(ret.toughness);
			if (currentCardPTRatio < params.PT_Ratio)
			{
				powerPreferred = true;
			}
			//Attempt to increment favouring power
			if (powerPreferred)
			{
				if (remainingPoints >= params.powerPointCost)
				{
					++ret.power;
					remainingPoints -= params.powerPointCost;
				}
				else if (remainingPoints >= params.toughnessPointCost)
				{
					++ret.toughness;
					remainingPoints -= params.toughnessPointCost;
				}
			}
			//Attempt to increment favouring toughness
			else
			{
				if (remainingPoints >= params.toughnessPointCost)
				{
					++ret.toughness;
					remainingPoints -= params.toughnessPointCost;
				}
				else if (remainingPoints >= params.powerPointCost)
				{
					++ret.power;
					remainingPoints -= params.powerPointCost;
				}
			}


		} while (remainingPoints >= params.powerPointCost || remainingPoints >= params.toughnessPointCost);
	}

	ret.name = params.name;

	//Cleanup end of text if " "
	if (ret.cardText != "")
	{
		if (ret.cardText.back() == ' ')
		{
			do
			{
				ret.cardText.pop_back();
			} while (ret.cardText.back() == ' ');

		}
	}
	return ret;
}
