#include "SetSkeleton.h"

SetSkeleton::SetSkeleton()
{
	keywordTally = nullptr;
	subtypeTally = nullptr;
}

void SetSkeleton::SetSetDataData(int setSize, std::map<std::string, TallyStruct::CombinedTally>* keywordTally, std::map<std::string, TallyStruct::SubTypeData>* subtypeTally)
{
	this->setSize = setSize;
	this->keywordTally = keywordTally;
	this->subtypeTally = subtypeTally;
}
