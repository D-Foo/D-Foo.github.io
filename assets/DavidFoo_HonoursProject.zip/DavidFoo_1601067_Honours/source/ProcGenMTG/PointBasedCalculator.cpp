#include "PointBasedCalculator.h"

PointBasedCalculator::PointBasedCalculator()
{
	vanillaCards = nullptr;
	keywordCards = nullptr;
	for (int i = 0; i < 5; ++i)
	{
		powerPointCost[i] = { 0.0f };
	}
}

PointBasedCalculator::~PointBasedCalculator()
{
}

void PointBasedCalculator::run()
{
#ifdef _DEBUG
	std::cout << "Running PBC\n";
#endif // _DEBUG
#ifdef _DEBUG
	std::cout << "Calculating Power and Toughness\n";
#endif // _DEBUG
	calculatePowerToughnessData();
#ifdef _DEBUG
	std::cout << "Calculating Power Point Cost\n";
#endif // _DEBUG
	calculatePowerPointCost();
#ifdef _DEBUG
	std::cout << "Calculating Keyword Cost";
#endif // _DEBUG
	calculateKeywordCost();
#ifdef _DEBUG
	std::cout << "Calculating Follow on Text Cost\n";
#endif // _DEBUG
	calculateFollowOnTextCardsPointCost();
}

void PointBasedCalculator::setVanillaCards(std::vector<MTGStruct::Card>* cards)
{
	vanillaCards = cards;
}

void PointBasedCalculator::setKeywordCards(std::vector<MTGStruct::Card>* cards)
{
	keywordCards = cards;
}

void PointBasedCalculator::setCardTextCards(std::vector<std::pair<MTGStruct::Card, std::string>>* cards)
{
	cardTextCards = cards;
}

int PointBasedCalculator::getPointsPerManaCost()
{
	return pointsPerManaCost;
}

PointBasedCalculator::PointData PointBasedCalculator::getPointData()
{
	PointData ret;
	ret.pointsPerManaCost = pointsPerManaCost;

	for (int i = 0; i < 5; ++i)
	{
		ret.toughnessPointCost[i] = toughnessPointCost;
		ret.powerPointCost[i] = powerPointCost[i];
	}

	for (int i = 0; i < 4; ++i)
	{
		ret.rarityPointMult[i] = 1.0f;	//Temp
	}

	ret.keywordCosts = keywordCosts;

	return ret;
}

float PointBasedCalculator::getPTRatio(MTGStruct::ColourIdentity colour)
{
	switch (colour)
	{
	case MTGStruct::ColourIdentity::Colourless:
		return data[5].ratio;
		break;
	case MTGStruct::ColourIdentity::W:
		return data[0].ratio;
		break;
	case MTGStruct::ColourIdentity::U:
		return data[1].ratio;
		break;
	case MTGStruct::ColourIdentity::B:
		return data[2].ratio;
		break;
	case MTGStruct::ColourIdentity::R:
		return data[3].ratio;
		break;
	case MTGStruct::ColourIdentity::G:
		return data[4].ratio;
		break;
	case MTGStruct::ColourIdentity::WU:
		break;
	case MTGStruct::ColourIdentity::WB:
		break;
	case MTGStruct::ColourIdentity::WR:
		break;
	case MTGStruct::ColourIdentity::WG:
		break;
	case MTGStruct::ColourIdentity::UB:
		break;
	case MTGStruct::ColourIdentity::UR:
		break;
	case MTGStruct::ColourIdentity::UG:
		break;
	case MTGStruct::ColourIdentity::BR:
		break;
	case MTGStruct::ColourIdentity::BG:
		break;
	case MTGStruct::ColourIdentity::WUB:
		break;
	case MTGStruct::ColourIdentity::WUR:
		break;
	case MTGStruct::ColourIdentity::WUG:
		break;
	case MTGStruct::ColourIdentity::WBR:
		break;
	case MTGStruct::ColourIdentity::WBG:
		break;
	case MTGStruct::ColourIdentity::WRG:
		break;
	case MTGStruct::ColourIdentity::UBR:
		break;
	case MTGStruct::ColourIdentity::UBG:
		break;
	case MTGStruct::ColourIdentity::URG:
		break;
	case MTGStruct::ColourIdentity::BRG:
		break;
	case MTGStruct::ColourIdentity::WUBR:
		break;
	case MTGStruct::ColourIdentity::WBRG:
		break;
	case MTGStruct::ColourIdentity::UBRG:
		break;
	case MTGStruct::ColourIdentity::WUBG:
		break;
	case MTGStruct::ColourIdentity::WURG:
		break;
	case MTGStruct::ColourIdentity::WUBRG:
		break;
	default:
		break;
	}
	return -1.0f;
}

void PointBasedCalculator::calculatePowerToughnessData()
{
	MTGStruct::ColourIdentity colours[6] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U,  MTGStruct::ColourIdentity::B,  MTGStruct::ColourIdentity::R,  MTGStruct::ColourIdentity::G,  MTGStruct::ColourIdentity::Colourless };


	for (int i = 0; i < 6; ++i)
	{
		std::vector<MTGStruct::Card> filteredCards = SetSearcher::filterByColourIdentity(*vanillaCards, colours[i]);



		int powerSum = 0.0f;
		int toughnessSum = 0.0f;
		int numCardsAdded = 0;
		int powerSumPerManaCost[MTGStruct::manaCostCap + 1] = { 0.0f };		//Store from CMC 0 up to and including 16
		int toughnessSumPerManaCost[MTGStruct::manaCostCap + 1] = { 0.0f };
		int numCardsPerManaCost[MTGStruct::manaCostCap + 1] = { 0 };
		std::map<int, int>modalPowerManaCostLog[MTGStruct::manaCostCap + 1] = { std::map<int, int>() };
		std::map<int, int>modalToughnessManaCostLog[MTGStruct::manaCostCap + 1] = { std::map<int, int>() };

		//Iterate through and pull card data
		for (auto& c : filteredCards)
		{
			if (c.standardPower && c.standardToughness)
			{
				if (c.CMC >= 0 && c.CMC <= MTGStruct::manaCostCap)
				{
					//Total
					++numCardsAdded;
					powerSum += c.power;
					toughnessSum += c.toughness;

					//Per Mana Cost
					++numCardsPerManaCost[c.CMC];
					powerSumPerManaCost[c.CMC] += c.power;
					toughnessSumPerManaCost[c.CMC] += c.toughness;

					//Modal Log
					//Power
					if (modalPowerManaCostLog[c.CMC].find(c.power) != modalPowerManaCostLog[c.CMC].end())
					{
						//Exists
						++modalPowerManaCostLog[c.CMC].find(c.power)->second;
					}
					else
					{
						//Insert
						modalPowerManaCostLog[c.CMC].insert(std::pair<int, int>(c.power, 1));
					}
					//Toughness
					if (modalToughnessManaCostLog[c.CMC].find(c.toughness) != modalToughnessManaCostLog[c.CMC].end())
					{
						//Exists
						++modalToughnessManaCostLog[c.CMC].find(c.toughness)->second;
					}
					else
					{
						//Insert
						modalToughnessManaCostLog[c.CMC].insert(std::pair<int, int>(c.toughness, 1));
					}
				}
			}
		}

		//Process card data
		//Calculate Averages
		data[i].averagePower = static_cast<float>(powerSum) / static_cast<float>(numCardsAdded);
		data[i].averageToughness = static_cast<float>(toughnessSum) / static_cast<float>(numCardsAdded);
		data[i].ratio = data[i].averagePower / data[i].averageToughness;

		for (int mc = 0; mc < MTGStruct::manaCostCap; ++mc)
		{
			//Check if cards were processed for this mana cost
			if (numCardsPerManaCost[mc])
			{
				//Get average PT for that mana cost
				data[i].averagePTForManaCost[mc].first = static_cast<float>(powerSumPerManaCost[mc]) / static_cast<float>(numCardsPerManaCost[mc]);
				data[i].averagePTForManaCost[mc].second = static_cast<float>(toughnessSumPerManaCost[mc]) / static_cast<float>(numCardsPerManaCost[mc]);

				//Find the most common power for this mana cost
				int maxCount = -1;
				int modalPower = -1;
				for (std::map<int, int>::iterator it = modalPowerManaCostLog[mc].begin(); it != modalPowerManaCostLog[mc].end(); ++it)
				{
					if (it->second > maxCount)
					{
						maxCount = it->second;
						modalPower = it->first;
					}
				}
				//Repeat for the most common toughness
				maxCount = -1;
				int modalToughness = -1;
				for (std::map<int, int>::iterator it = modalToughnessManaCostLog[mc].begin(); it != modalToughnessManaCostLog[mc].end(); ++it)
				{
					if (it->second > maxCount)
					{
						maxCount = it->second;
						modalToughness = it->first;
					}
				}

				data[i].modalPTForManaCost[mc] = std::pair<int, int>(modalPower, modalToughness);
			}
			else
			{
				data[i].averagePTForManaCost[mc].first = -1.0f;
				data[i].averagePTForManaCost[mc].second = -1.0f;
				data[i].modalPTForManaCost[mc] = std::pair<int, int>(-1, 1);
			}


			
		}
		
	
	}

}

//For each colour calculate the number of points each point of power costs
void PointBasedCalculator::calculatePowerPointCost()
{
	MTGStruct::ColourIdentity colours[5] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U,  MTGStruct::ColourIdentity::B,  MTGStruct::ColourIdentity::R,  MTGStruct::ColourIdentity::G };


	for (int i = 0; i < 5; ++i)
	{
		std::vector<MTGStruct::Card> filteredCards = SetSearcher::filterByColourIdentity(*vanillaCards, colours[i]);


		int powerSum = 0.0f;
		int toughnessSum = 0.0f;
		int numCardsAdded = 0;
		int manaCostSum = 0;

		//Sum Data
		for (auto& c : filteredCards)
		{
			if (c.standardPower && c.standardToughness)
			{
				powerSum += c.power;
				toughnessSum += c.toughness;
				manaCostSum += c.CMC;
				++numCardsAdded;
			}
		}

		//Calculate powerPointCost
		int pointsSum = pointsPerManaCost * manaCostSum;
		float toughnessPoints = toughnessPointCost * toughnessSum;
		float remainingPoints = pointsSum - toughnessPoints;

		powerPointCost[i] = remainingPoints / static_cast<float>(powerSum);
	}
}


//Calculate KW cost for mono coloured cards
void PointBasedCalculator::calculateKeywordCost()
{
	//Create copy of keyword cards
	std::vector<MTGStruct::Card> keywordCopy = *keywordCards;
	std::vector<MTGStruct::Card> currentKeywordCards;

	if (!keywordCopy.empty())
	{
		do
		{
			//Get Keyword
			std::string kw = keywordCopy.front().keywords[0];

			//Find all of that keyword
			for (std::vector<MTGStruct::Card>::iterator it = keywordCopy.begin(); it != keywordCopy.end(); ++it)
			{
				if (it->keywords[0] == kw)
				{
					//Remove and add to local vector
					currentKeywordCards.push_back(*it);
					it = keywordCopy.erase(it);
					if (it == keywordCopy.end())
					{
						break;
					}
				}
			}

			float kwCostSum = 0.0f;
			int numCards = 0;
			MTGStruct::ColourIdentity colourMap[5] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U, MTGStruct::ColourIdentity::B, MTGStruct::ColourIdentity::R, MTGStruct::ColourIdentity::G };


			//Get estimated point cost of card
			for (auto& c : currentKeywordCards)
			{
				if (c.standardPower && c.standardToughness)
				{
					int colourID = -1;
					for (int i = 0; i < 5; ++i)
					{
						if (colourMap[i] == c.colourIdentity)
						{
							colourID = i;
							break;
						}
					}

					//Diff in estimated vs actual = KW Cost
					float kwCost = (pointsPerManaCost * c.CMC) - ((c.power * powerPointCost[colourID]) + (c.toughness * toughnessPointCost));
					kwCostSum += kwCost;
					++numCards;
				}
			}

			//Calculate average kwCost
			float averageKeywordCost = kwCostSum / static_cast<float>(numCards);
			keywordCosts.insert(std::pair<std::string, float>(kw, averageKeywordCost));


			currentKeywordCards.clear();

		} while (!keywordCopy.empty());	//Repeat until copy empty
	}
	
}

void PointBasedCalculator::calculateFollowOnTextCardsPointCost()
{
	MTGStruct::ColourIdentity colourMap[5] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U, MTGStruct::ColourIdentity::B, MTGStruct::ColourIdentity::R, MTGStruct::ColourIdentity::G };

	for (auto& c : *cardTextCards)
	{
		//GET Estimated points available to card
		float pointsAvailable = c.first.CMC * pointsPerManaCost;
		

		int colourID = -1;
		//Subptract points on p + t
		if (c.first.standardPower && c.first.standardToughness)
		{
			
			for (int i = 0; i < 5; ++i)
			{
				if (colourMap[i] == c.first.colourIdentity)
				{
					colourID = i;
					break;
				}
			}
			if (colourID != -1)
			{
				pointsAvailable -= c.first.power * powerPointCost[colourID];
				pointsAvailable -= c.first.toughness * toughnessPointCost;

				//Subtract points based on keywords
				for (auto& kw : c.first.keywords)
				{
					if (keywordCosts.find(kw) != keywordCosts.end())
					{
						pointsAvailable -= keywordCosts.find(kw)->second;
					}
					else
					{
#ifdef _DEBUG
						//cerr << "Error: could not find keyword " << kw << " in " << "PointBasedCalculator" << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n"; Currently being hit as ETB text can contain keywords e.g. Mill, Bolster, Surveil
#endif // _DEBUG
					}
				}

				//Get estimate of points cost of cards follow on text
				cardTextCosts.insert(std::pair<std::string, float>(c.second, pointsAvailable));

				//Store in cardTexts for retrieval for setParams
				std::tuple<std::string, float, MTGStruct::Rarity, int> data;
				std::get<0>(data) = c.second;
				std::get<1>(data) = pointsAvailable;
				std::get<2>(data) = c.first.rarity;
				std::get<3>(data) = c.first.CMC;

				cardTexts[colourID].push_back(data);
			}
		}
		
	}
}
