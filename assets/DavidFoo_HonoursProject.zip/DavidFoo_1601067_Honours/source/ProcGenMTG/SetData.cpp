#include "SetData.h"

SetData::SetData()
{
	setName = "";
	setSize = 0;
	for (int i = 0; i < MTGStruct::numColourIdentities; ++i)
	{
		colourIdentityTally[i] = 0;
	}
}

SetData::~SetData()
{
}

void SetData::addKeyword(std::string keyword, bool W, bool U, bool B, bool R, bool G, MTGStruct::Rarity rarity, std::string creatureSubtype)
{
	//--Log in keywordTally--

	//Check if keyword already stored
	std::map <std::string, TallyStruct::CombinedTally>::iterator it = keywordTally.find(keyword);
	if (it == keywordTally.end())
	{
		//Keyword not found so store keyword
		std::pair<std::string, TallyStruct::CombinedTally> kT;
		kT.first = keyword;
		keywordTally.insert(kT);
	}
	//Point it to keyword
	it = keywordTally.find(keyword);

	if (it != keywordTally.end())
	{
		//Log keyword colour and rarity data
		bool colours[5] = { W, U, B ,R, G };
		for (int i = 0; i < 5; ++i)
		{
			if (colours[i])
			{
				++it->second.colours[i].first; 
				++it->second.colours[i].second.tally[static_cast<int>(rarity)];
			}
		}

		if (!W && !U && !B && !R && !G)
		{
			++it->second.colours[5].first; ++it->second.colours[5].second.tally[static_cast<int>(rarity)];
		}
	}
	else
	{
#ifdef _DEBUG
		cerr << "Error: Couldn't find keyword in map in " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG		
	}

	//--Log in subtypeKeywordTally--
	std::map <std::string, std::map<std::string, int>>::iterator it2 = subtypeKeywordTally.find(creatureSubtype);
	if (it2 == subtypeKeywordTally.end())
	{
		//Subtype not found so store subtype
		std::pair <std::string, std::map<std::string, int>> sKT;
		sKT.first = creatureSubtype;
		subtypeKeywordTally.insert(sKT);
	}
	
	it2 = subtypeKeywordTally.find(creatureSubtype);
	
	if (it2 != subtypeKeywordTally.end())
	{
		//Log subtpye keyword data
		std::map<std::string, int>::iterator it3 = it2->second.find(keyword);
		if (it3 == it2->second.end())
		{
			//Keyword not present on this subtype so add it
			std::pair<std::string, int> sKTKW;
			sKTKW.first = keyword;
			sKTKW.second = 0;
			it2->second.insert(sKTKW);
		}
		//Increment the subtype keyword tally
		++it2->second.find(keyword)->second;
	}
	else
	{
#ifdef _DEBUG
		cerr << "Error: Couldn't find keyword in map in " << typeid(this).name() << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG		
	}
}

void SetData::addSubtypes(std::string primarySubtype, std::vector<std::string> secondarySubtypes, bool W, bool U, bool B, bool R, bool G, MTGStruct::Rarity rarity)
{

	//Check if primary subtype already stored
	std::map <std::string, TallyStruct::SubTypeData>::iterator it = subtypeTally.find(primarySubtype);

	if (it == subtypeTally.end())	//Not found so add it
	{
		std::pair<std::string, TallyStruct::SubTypeData> st;
		st.first = primarySubtype;
		st.second.numberTimesSeen = 0;
		subtypeTally.insert(st);
	}
	it = subtypeTally.find(primarySubtype);

	if (it != subtypeTally.end())
	{
		//Increment subtype data
		bool colours[5] = { W, U, B ,R, G };

		for (int i = 0; i < 5; ++i)
		{
			if (colours[i])
			{
				++it->second.ct.colours[i].first;
				++it->second.ct.colours[i].second.tally[static_cast<int>(rarity)];
				
			}
		}

		if (!W && !U && !B && !R && !G)
		{
			++it->second.ct.colours[5].first; 
			++it->second.ct.colours[5].second.tally[static_cast<int>(rarity)];
		}

		++it->second.numberTimesSeen;

		//Add subtypes
		if (!secondarySubtypes.empty())
		{
			//Add subtype strings
			std::map<std::vector<std::string>, TallyStruct::CombinedTally>::iterator it2 = it->second.secondaries.find(secondarySubtypes);
			if (it2 == it->second.secondaries.end())
			{
				std::pair<std::vector<std::string>, TallyStruct::CombinedTally> st2;
				st2.first = secondarySubtypes;
				it->second.secondaries.insert(st2);
			}
			it2 = it->second.secondaries.find(secondarySubtypes);

			//Add colour and rarity data
			if (it2 != it->second.secondaries.end())
			{
				//Increment keyword data
				for (int i = 0; i < 5; ++i)
				{
					if (colours[i])
					{
						++it2->second.colours[i].first;
						++it2->second.colours[i].second.tally[static_cast<int>(rarity)];
					}
				}

				if (!W && !U && !B && !R && !G)
				{
					++it2->second.colours[5].first; ++it2->second.colours[5].second.tally[static_cast<int>(rarity)];
				}
			}
		}
	}
	else
	{
		cerr << "Couldn't find primarySubtype after inserting it\n";
	}
}

void SetData::addColourIdentity(MTGStruct::ColourIdentity ci)
{
	colourIdentityTally[static_cast<int>(ci)]++;
}

void SetData::outputKeywordTallyData()
{

	cout << "\n\nKeyword Tally:\n";
	for (auto& kt : keywordTally)
	{
		cout << kt.first;
		cout << ": \t";

		if (static_cast<int>(kt.first.length()) < 14)
		{
			cout << "\t";
		}

		if (static_cast<int>(kt.first.length()) < 6)
		{
			cout << "\t";
		}

		char colourCharacters[6] = { 'W', 'U', 'B', 'R', 'G', 'C' };

		for (int i = 0; i < 6; ++i)
		{
			if (i)
			{
				cout << "\t";
			}
			cout << colourCharacters[i] << ": " << kt.second.colours[i].first;
		}
		cout << "\n";
	}
	cout << "\n";
}

void SetData::createKeywordColourWeights()
{
	struct PercentageTracker
	{
		std::string keywordName = "";
		int timesSeen = 0;
		float percentages[6] = { 0.0f };
	};
	int colourMap[6] = { 1, 2, 3, 4, 5, 0 };	//Maps i to colour IdentityTally index for mono coloured cards
	std::string colourStrings[6] = { "White", "Blue", "Black", "Red", "Green", "Colourless" };

	//Calculate percentage of cards a keyword occurs on in a colour
	//std::vector<std::pair<std::string, float[6]>> percentages;
	std::vector<PercentageTracker> percentages;

	for (auto& kt : keywordTally)
	{
		int timesSeen = 0;
		for (int i = 0; i < 6; ++i)
		{
			timesSeen += kt.second.colours[i].first;
		}
		PercentageTracker p;
		p.keywordName = kt.first;
		p.timesSeen = timesSeen;
		for (int i = 0; i < 6; ++i)
		{
			
									

			//p.second[i] = (static_cast<float>(kt.second.colours[i].first) / static_cast<float>(colourIdentityTally[colourMap[i]])) * 100;
			p.percentages[i] = (static_cast<float>(kt.second.colours[i].first) / static_cast<float>(timesSeen)) * 100;
		}
	
		percentages.push_back(p);

		//Categorize

		for (int i = 0; i < 6; ++i)
		{
			for (int j = 2; j >= 0;--j)
			{
				if (p.percentages[i] > thresholdPercentages[j])
				{
					std::string thresholdString = "Tertiary";
					if(j == 2)
					{
						thresholdString = "Primary";
					}
					else if (j == 1)
					{
						thresholdString = "Secondary";
					}
					std::cout << p.keywordName << " is " << thresholdString << " for " << colourStrings[i] << "\n";
					break;
				}
			}
		}
	}
}

SetData SetData::combineWithSet(SetData* set2)
{
	SetData ret;
	std::string retName = "CombinedSet(";
	retName.append(setName);
	retName.append(", ");
	retName.append(set2->getSetName());
	retName.append(")");
	ret.setSetName(retName);

	ret.setSetSize(setSize + set2->getSetSize());

	//Get Set Data from set 2
	//Aggregate Keywords
	std::map <std::string, TallyStruct::CombinedTally> aggregatedKeywordTally = keywordTally;
	std::map <std::string, TallyStruct::CombinedTally> set2KeywordTally = *set2->getKeywordTally();
	
	for (auto& kt : set2KeywordTally)
	{
		std::map <std::string, TallyStruct::CombinedTally>::iterator it = aggregatedKeywordTally.find(kt.first);
		if (it == aggregatedKeywordTally.end())
		{
			//Keyword not found so store keyword
			aggregatedKeywordTally.insert(kt);
		}
		else
		{
			it->second += kt.second;	
		}
	}

	//Aggregate Subtypes
	std::map <std::string, TallyStruct::SubTypeData> aggregatedSubTypeData = subtypeTally;
	std::map <std::string, TallyStruct::SubTypeData> set2SubTypeData = *set2->getSubtypeTally();

	//For each primary subtype
	for (auto& st : set2SubTypeData)
	{
		//Check if primary subtype is already stored
		std::map <std::string, TallyStruct::SubTypeData>::iterator it = aggregatedSubTypeData.find(st.first);
		if (it == aggregatedSubTypeData.end())
		{
			//If it isn't store it and it's data
			aggregatedSubTypeData.insert(st);
		}
		else
		{
			//Else aggregate the secondary subtypes
			it->second += st.second;
		}
	}

	//Aggregate ColourIdentity Tally
	int aggregatedColourIdentityTally[MTGStruct::numColourIdentities];
	for (int i = 0; i < MTGStruct::numColourIdentities; ++i)
	{
		aggregatedColourIdentityTally[i] = colourIdentityTally[i] + set2->colourIdentityTally[i];
	}

	//Aggregate subtypeKeywordTally
	std::map <std::string, std::map<std::string, int>> aggregatedSubtypeKeywordTally = subtypeKeywordTally;
	std::map <std::string, std::map<std::string, int>> set2SubTypeKeywordTallyData = *set2->getSubtypeKeywordTally();
	//For each  subtype
	for (auto& st : set2SubTypeKeywordTallyData)
	{
		//Check if  subtype is already stored
		std::map <std::string, std::map<std::string, int>>::iterator it = aggregatedSubtypeKeywordTally.find(st.first);
		if (it == aggregatedSubtypeKeywordTally.end())
		{
			//If it isn't store it and it's data
			aggregatedSubtypeKeywordTally.insert(st);
		}
		else
		{
			//Else aggregate the keywords on that subtype
			for (auto& kw : st.second)
			{
				std::map<std::string, int>::iterator it2 = it->second.find(kw.first);
				//Check if keyword is already stored
				if (it2 == it->second.end())
				{
					//If it isn't store it and it's data
					it->second.insert(kw);
				}
				else
				{
					//Else aggregate the keyword data
					it2->second += kw.second;
				}
			}

		}
	}


	//Store in ret
	ret.keywordTally = aggregatedKeywordTally;
	ret.subtypeTally = aggregatedSubTypeData;
	ret.subtypeKeywordTally = aggregatedSubtypeKeywordTally;
	for (int i = 0; i < MTGStruct::numColourIdentities; ++i)
	{
		ret.colourIdentityTally[i] = colourIdentityTally[i] + set2->colourIdentityTally[i];
	}

	return ret;
}

std::vector<std::string> SetData::getKeywords()
{
	std::vector<std::string> ret;

	for (auto& s : keywordTally)
	{
		ret.push_back(s.first);
	}

	return ret;
}

