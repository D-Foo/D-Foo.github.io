#pragma once
#include "Skeleton_Structures.hpp"
#include "Tally_Structures.hpp"
#include "CardSkeleton.h"
#include <map>

class SetSkeleton
{
public:
	SetSkeleton();

	void SetSetDataData(int setSize, std::map <std::string, TallyStruct::CombinedTally>* keywordTally, std::map <std::string, TallyStruct::SubTypeData>* subtypeTally);
private:
	

	Skeleton::ColourWeights colourWeights[6];	//CWUBRG
	
	//Set Data 
	int setSize;
	std::map <std::string, TallyStruct::CombinedTally>* keywordTally;	//From Set Data
	std::map <std::string, TallyStruct::SubTypeData>* subtypeTally;		//From Set Data

};

