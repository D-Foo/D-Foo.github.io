#pragma once
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include "MTG_Structures.hpp"
#include "rapidjson\document.h"
#include "SetData.h"
#include "pugixml.hpp"

using std::cout;
using std::cin;
using std::cerr;

class SetParser
{
public:
	SetParser();
	~SetParser();

	std::vector<MTGStruct::Card> parseSetJSON(const char* filepath, SetData* setData, bool outputIncorrectlyLoadedCards, bool storeIncorrectlyLoadedCards, std::vector<MTGStruct::Supertype> supertypes);
	//std::vector<MTGStruct::Card> parseSetXML(const char* filepath, SetData* setData, bool outputIncorrectlyLoadedCards, bool storeIncorrectlyLoadedCards);	<-- Implement This
	void saveXML(std::vector<MTGStruct::Card>& cards, std::string setName);
	void setOnlyParseMonoColouredCards(bool parseMono);
private:
	bool loadSetFromJSON(rapidjson::Document& doc, std::vector<MTGStruct::Card>& set, SetData* setData, bool outputIncorrectlyLoadedCards, bool storeIncorrectlyLoadedCards, std::vector<MTGStruct::Supertype> supertypes);
	bool loadCardFromJSON (rapidjson::Document& doc, const rapidjson::Value& cardArray, MTGStruct::Card& card, std::vector<MTGStruct::Supertype> supertypes);
	bool storeCardDataInSetData(MTGStruct::Card* card, SetData* setData);
	std::string loadJSON(const char* filepath);
	bool onlyParseMonoColouredCards;
	bool parseFuseOrFlipCards;
	bool onlyParseCreatures;
};

