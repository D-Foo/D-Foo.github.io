#pragma once
#include <array>
#include "SFML/Window.hpp"

//Handles key presses in conjunction with SFML
class KeyboardInput
{
public:
	KeyboardInput();
	~KeyboardInput();

	void updateLastFrameKeys();

	bool onKeyDown(sf::Keyboard::Key keyCode);
	bool isKeyDown(sf::Keyboard::Key keyCode);
	bool onKeyUp(sf::Keyboard::Key keyCode);

	void setKeyDown(sf::Keyboard::Key keyCode);
	void setKeyUp(sf::Keyboard::Key keyCode);
	void setAllFalse() { keys.fill(false); };

private:
	static const int keySize = 264;
	std::array<bool, keySize> keys;
	std::array<bool, keySize> lastFrameKeys;
};