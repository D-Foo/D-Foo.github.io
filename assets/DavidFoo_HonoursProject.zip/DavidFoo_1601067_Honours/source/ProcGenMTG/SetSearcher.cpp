#include "SetSearcher.h"

SetSearcher::SetSearcher()
{
}

SetSearcher::~SetSearcher()
{
}

//Function Template
//std::vector<MTGStruct::Card> SetSearcher::REPLACE_ME(std::vector<MTGStruct::Card>& cards)
//{
//    std::vector<MTGStruct::Card> ret;
//
//   for (auto& c : cards)
//   {
//
//   }
//
//    return ret;
//}


std::vector<MTGStruct::Card> SetSearcher::getVanillaCreatures(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.cardText == "" && c.supertype == MTGStruct::Supertype::Creature)
        {
            ret.push_back(c);
        }
    }
    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterByColourIdentity(std::vector<MTGStruct::Card>& cards, MTGStruct::ColourIdentity colour)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.colourIdentity == colour)
        {
            ret.push_back(c);
        }
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterToCreatures(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.supertype == MTGStruct::Supertype::Creature || c.supertype == MTGStruct::Supertype::ArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentCreature || c.supertype == MTGStruct::Supertype::LandCreature)
        {
            ret.push_back(c);
        }
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterOutCreatures(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.supertype != MTGStruct::Supertype::Creature && c.supertype != MTGStruct::Supertype::ArtifactCreature && c.supertype != MTGStruct::Supertype::EnchantmentArtifactCreature && c.supertype != MTGStruct::Supertype::EnchantmentCreature && c.supertype != MTGStruct::Supertype::LandCreature)
        {
            ret.push_back(c);
        }
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterByNumKeywords(std::vector<MTGStruct::Card>& cards, size_t numKeywords)
{
    std::vector<MTGStruct::Card> ret;

   for (auto& c : cards)
   {
       if (c.keywords.size() == numKeywords)
       {
           ret.push_back(c);
       }
   }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterToKeywordOnly(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

   for (auto& c : cards)
   {
       std::string cardText = c.cardText;

       bool cardHasKeywordOnly = false;
       if (cardText != "")
       {
           cardHasKeywordOnly = false;

           //Remove all text in between()
           while (cardText.find('(') != std::string::npos)
           {
               std::size_t rightB = cardText.find(')');
               std::size_t leftB = cardText.find('(');
               std::size_t diff = cardText.find(')') - cardText.find('(');
               cardText.erase(cardText.find('('), cardText.find(')') - cardText.find('(') + 1);
           }

           //Remove all keywords 
           for (auto& k : c.keywords)
           {
               //Remove them from the cardText
               while (cardText.find(k) != std::string::npos)
               {
                   cardText.erase(cardText.find(k), k.length());
                   cardHasKeywordOnly = true;
               }

           }

           //Remove all " "
           while (cardText.find(' ') != std::string::npos)
           {
               cardText.erase(cardText.find(' '), 1);
           }
           //Check 
           if (cardText != "")
           {    
               //Card text contains text other than the keyword(s)
               cardHasKeywordOnly = false;
           }

           if (cardHasKeywordOnly)
           {
               ret.push_back(c);
           }
       }
   }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterToTargetPower(std::vector<MTGStruct::Card>& cards, int powerTarget)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.supertype == MTGStruct::Supertype::Creature || c.supertype == MTGStruct::Supertype::ArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentCreature || c.supertype == MTGStruct::Supertype::LandCreature)
        {
            if (c.power == powerTarget)
            {
                ret.push_back(c);
            }
        }
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterByCardText(std::vector<MTGStruct::Card>& cards, std::string str, bool exclusive, bool inverse)
{
    //Specific strings will allow for context relevant strings:
    //_CARD_NAME will be substituted with the cards name in
    //_NUMBER will allow for any number between one and twenty

    std::vector<MTGStruct::Card> ret;

  
    size_t cardNameLengthDiff = 0;
    bool checkCardName = false;
    if (str.find("_CARD_NAME") != std::string::npos)
    {
        checkCardName = true;
    }

    int matchStart = 0;

    for (auto& c : cards)
    {
        std::vector<std::string> strAsWords = strToVec(str);    //str converted from single string to each term separated by whitespace

        //Replace _CARD_NAME in string with card name
        if (checkCardName)
        {
            std::vector<std::string> cardNameAsWords = strToVec(c.name);
            cardNameLengthDiff = cardNameAsWords.size() - static_cast<size_t>(1);
            for (int i = 0; i < strAsWords.size(); ++i)
            {
                if (strAsWords[i] == "_CARD_NAME")
                {
                    for (size_t j = 0; j < cardNameAsWords.size(); ++j)
                    {
                        if (j > 0)
                        {
                            strAsWords.insert(strAsWords.begin() + i + j, cardNameAsWords[j]);
                        }
                        else
                        {
                            strAsWords[i] = cardNameAsWords[0];
                        }
                    }
                }
            }
        }

        std::string stringToCheck = c.cardText;
        std::vector<std::string> strToCheckAsWords = strToVec(stringToCheck);
        bool inverseMatchFound = false;

        for (int i = 0; i < static_cast<int>(strToCheckAsWords.size()); ++i)
        {
            

            //Check for initial match
            if (compareStr(strAsWords[0], strToCheckAsWords[i], c.name).first)
            {
                bool match = true;
                matchStart = i;
                //If found check following strings in card text vs strAsWords
                for (int j = 1; j < static_cast<int>(strAsWords.size()); ++j)
                {
                    //Make sure we don't go past the remaining card text words
                    if (i + j >= static_cast<int>(strToCheckAsWords.size()))
                    {
                        match = false;
                        break;
                    }
                    else if (!compareStr(strAsWords[j], strToCheckAsWords[i + j], c.name).first)
                    {
                        match = false;
                        break;
                    }
                }
                //If true add to ret
                if (match && !inverse)
                {
                    //If match start and match end != 0 && cardText.size() !exclusive
                    if( (exclusive && matchStart != 0) || (exclusive && strAsWords.size() != strToCheckAsWords.size()) )
                    {
                        //Don't add card
                    }
                    else
                    {
                        ret.push_back(c);
                        break;
                    }
                }

                if (match && inverse)
                {
#ifdef _DEBUG
                    std::cout << "Filtered out " << c.name << ", contained: \"" << str << "\"\n";
#endif // _DEBUG
                    inverseMatchFound = true;
                }

                
            }
          
        }
        if (inverse && !inverseMatchFound)
        {
            ret.push_back(c);
        }
      
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterToEquipment(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.supertype == MTGStruct::Supertype::Artifact)
        {
            bool equipment = false;
            for (auto& s : c.subtypes)
            {
                if (s == "Equipment")
                {
                    equipment = true;
                }
            }
            if (equipment)
            {
                ret.push_back(c);
            }
        }
    }

    return ret;
}

std::vector<MTGStruct::Card> SetSearcher::filterToActivatedArtifacts(std::vector<MTGStruct::Card>& cards)
{
    std::vector<MTGStruct::Card> ret;

    for (auto& c : cards)
    {
        if (c.supertype == MTGStruct::Supertype::Artifact)
        {
            bool notEquipment = true;

            for (auto& s : c.subtypes)
            {
                if (s == "Equipment")
                {
                    notEquipment = false;
                    break;
                }
            }

            if (notEquipment)
            {
                ret.push_back(c);
            }
        }
    }

    //TODO TEST JUST CHECKING FOR ":" (This won't pick up sac a creature:, currently)
    std::vector<MTGStruct::Card> manaCostActivatedArtifacts = filterByCardText(ret, "_MANA_ACTIVATED_ABILITY", false);
    std::vector<MTGStruct::Card> tapActivatedArtifacts = filterByCardText(ret, "_TAP_ACTIVATED_ABILITY", false);


    //Check for duplicates

    if (manaCostActivatedArtifacts.size() >= tapActivatedArtifacts.size())
    {
        ret = manaCostActivatedArtifacts;
        for (auto& c : tapActivatedArtifacts)
        {
            bool duplicate = false;
            for (auto& ca : ret)
            {
                if (c.name == ca.name)
                {
                    duplicate = true;
                    break;
                }
            }
            //Add card
            if (!duplicate)
            {
                ret.push_back(c);
            }
        }
    }
    else
    {
        ret = tapActivatedArtifacts;
        for (auto& c : manaCostActivatedArtifacts)
        {
            bool duplicate = false;
            for (auto& ca : ret)
            {
                if (c.name == ca.name)
                {
                    duplicate = true;
                    break;
                } 
            }
            //Add card
            if (!duplicate)
            {
                ret.push_back(c);
            }
        }
    }

    return ret;
}

std::vector<std::tuple<std::string, int, MTGStruct::ColourIdentity>> SetSearcher::getFollowOnTextToString(std::vector<MTGStruct::Card>& cards, std::string str)
{
    std::vector<std::tuple<std::string, int, MTGStruct::ColourIdentity>>  ret;
  
    std::vector<std::string> strAsWords = strToVec(str);    //str converted from single string to each term separated by whitespace
   
    //Check if card text contains str
    for (auto& c : cards)
    {
        int indexFound = searchCardTextForStr(str, c.cardText, c.name);
        std::string followOnText = "";
        if (indexFound)
        {
            //YES

            //Get substr between position and next '.'
            std::string _CARD_NAME = "_CARD_NAME";
            if (str.find(_CARD_NAME) != std::string::npos)
            {
                size_t cardNameLengthDiff = c.name.length() - _CARD_NAME.length();
                followOnText = c.cardText.substr((static_cast<size_t>(indexFound) + str.length() + cardNameLengthDiff), c.cardText.find_first_of('.', static_cast<size_t>(indexFound) + str.length() + cardNameLengthDiff) - static_cast<size_t>(indexFound) - str.length() - cardNameLengthDiff + 1);
            }
            else
            {
                followOnText = c.cardText.substr((static_cast<size_t>(indexFound) + str.length()), c.cardText.find_first_of('.', static_cast<size_t>(indexFound) + str.length()) - static_cast<size_t>(indexFound) - str.length() + 1);
            }
           

            //Check if str is in ret

            bool cardFound = false;
            for (auto& t : ret)
            {
                if (std::get<0>(t) == str)
                {
                    //YES - Increment counter
                    ++std::get<1>(t);
                    
                    //Update ColourIdentity
                    MTGStruct::ColourIdentity ci = std::get<2>(t);
                    bool recordedCIParts[5] = { false };
                    MTGStruct::PartsFromColourIdentity(recordedCIParts[0], recordedCIParts[1], recordedCIParts[2], recordedCIParts[3], recordedCIParts[4], ci);
                    bool newCIParts[5] = { false };
                    MTGStruct::PartsFromColourIdentity(newCIParts[0], newCIParts[1], newCIParts[2], newCIParts[3], newCIParts[4], c.colourIdentity);

                    //Merge CI
                    bool aggregatedCI[5] = { false };
                    for (int i = 0; i < 5; ++i)
                    {
                        aggregatedCI[i] = recordedCIParts[i] || newCIParts[i];
                    }

                    //Save new CI
                    std::get<2>(t) = MTGStruct::ColourIdentityFromParts(aggregatedCI[0], aggregatedCI[1], aggregatedCI[2], aggregatedCI[3], aggregatedCI[4]);

                    cardFound = true;
                    break;
                }
                
            }
            if (!cardFound)
            {
                //NO -Add to ret

                std::tuple<std::string, int, MTGStruct::ColourIdentity> data;
                std::get<0>(data) = c.name;
                std::get<1>(data) = 1;
                std::get<2>(data) = c.colourIdentity;

                ret.push_back(data);
            }
        }   
    }


    bool sorted = false;
    do
    {
        sorted = true;
        for (int i = 0; i < static_cast<int>(ret.size()) - 1; ++i)
        {
            if (std::get<1>(ret[i]) < std::get<1>(ret[i + 1]))
            {
                sorted = false;
                int temp = std::get<1>(ret[i + 1]);
                std::get<1>(ret[i + 1]) = std::get<1>(ret[i]);
                std::get<1>(ret[i]) = temp;
            }
        }


    } while (!sorted);

    return ret;
}

std::vector<std::pair<MTGStruct::Card, std::string>> SetSearcher::filterByLeadInText(std::vector<MTGStruct::Card>& cards, std::string str, std::array<std::string, MTGStruct::numKeywords> keywords)
{
    std::vector<std::pair<MTGStruct::Card, std::string>> ret;

    std::vector<std::string> strAsWords = strToVec(str);    //str converted from single string to each term separated by whitespace

    //Check if card text contains str
    for (auto& c : cards)
    {
        int indexFound = searchCardTextForStr(str, c.cardText, c.name);
        std::string followOnText = "";

        if (indexFound)
        {
            //YES

            //Get substr between position and next '.'
            std::string _CARD_NAME = "_CARD_NAME";
            size_t cardNameLengthDiff = 0;

            if (str.find(_CARD_NAME))
            {
                cardNameLengthDiff = c.name.length() - _CARD_NAME.length();
                followOnText = c.cardText.substr((static_cast<size_t>(indexFound) + str.length() + cardNameLengthDiff), c.cardText.find_first_of('.', static_cast<size_t>(indexFound) + str.length() + cardNameLengthDiff) - static_cast<size_t>(indexFound) - str.length() - cardNameLengthDiff + 1);
            }
            else
            {
                followOnText = c.cardText.substr((static_cast<size_t>(indexFound) + str.length()), c.cardText.find_first_of('.', static_cast<size_t>(indexFound) + str.length()) - static_cast<size_t>(indexFound) - str.length() + 1);
            }


            //Remove lead in & follow on from str
            std::string cardText = c.cardText;
            cardText.erase(cardText.begin() + static_cast<size_t>(indexFound), cardText.begin() + static_cast<size_t>(indexFound) + str.length() + cardNameLengthDiff + followOnText.length());
            
            //Remove all " "
            while (cardText.find(" ") != std::string::npos)
            {
                cardText.erase(cardText.find(" "), size_t(1));
            }

            //Remove key words from str
            for (auto& kw : keywords)
            {
                size_t kwIndex = cardText.find(kw);
                if (kwIndex != std::string::npos)
                {
                    cardText.erase(kwIndex, kwIndex + kw.length());
                }
            }

            //Remove any text between '(' ')' inclusive
            while (cardText.find_first_of("(") != std::string::npos)
            {
                //Find first ')' after the first '('
                if (cardText.find_first_of(")", cardText.find_first_of("(")) != std::string::npos)
                {
                    cardText.erase(cardText.find_first_of("("), cardText.find_first_of(")", cardText.find_first_of("(")) + static_cast<size_t>(1));
                }
                else
                {
                    break;
                }
            }

            //Remove any ',' or '.' or '\n'
            while (cardText.find(",") != std::string::npos)
            {
                cardText.erase(cardText.find(","), size_t(1));
            }
            while (cardText.find(".") != std::string::npos)
            {
                cardText.erase(cardText.find("."), size_t(1));
            }
            while (cardText.find("\n") != std::string::npos)
            {
                cardText.erase(cardText.find("\n"), size_t(1));
            }

            //Check if any remaining text
            bool remainingText = false;
            cardText.size() > static_cast<size_t>(0) ? remainingText = true : remainingText = false;

            if (remainingText)
            {

            }
            else
            {
                std::string cardText = str;
                cardText.append(followOnText);

                ret.push_back(std::pair<MTGStruct::Card, std::string>(c, cardText));
            }           
        }
    }
    return ret;
}

int SetSearcher::searchCardTextForStr(std::string strToSearchFor, std::string cardText, std::string cardName)
{
    std::vector<std::string> cardTextAsWords = strToVec(cardText);
    std::vector<std::string> strToSearchForAsWords = strToVec(strToSearchFor);
    std::vector<std::string> cardNameAsWords = strToVec(cardName);

    //MODIFY strToSearchFor if it contains _CARD_NAME
    for (size_t i = 0; i < strToSearchForAsWords.size(); ++i)
    {
        if (strToSearchForAsWords[i] == "_CARD_NAME")
        {
            for (size_t j = 0; j < cardNameAsWords.size(); ++j)
            {
                if (j > 0)
                {
                    strToSearchForAsWords.insert(strToSearchForAsWords.begin() + i + j, cardNameAsWords[j]);
                }
                else
                {
                    strToSearchForAsWords[i] = cardNameAsWords[0];
                }
            }
        }
    }

    std::string strFound = ""; //The string found in the card text

    for (int i = 0; i < static_cast<int>(cardTextAsWords.size()); ++i)
    {
        //Check for initial match
        if (compareStr(strToSearchForAsWords[0], cardTextAsWords[i], cardName).first)
        {
            bool match = true;
            strFound = compareStr(strToSearchForAsWords[0], cardTextAsWords[i], cardName).second;

            //If found check following strings in card text vs strAsWords
            for (int j = 1; j < static_cast<int>(strToSearchForAsWords.size()); ++j)
            {
                //Make sure we don't go past the remaining card text words
                if (i + j >= static_cast<int>(cardTextAsWords.size()))
                {
                    match = false;
                    break;
                }

                //Compare
                std::pair<bool, std::string> strComparison = compareStr(strToSearchForAsWords[j], cardTextAsWords[i + j], cardName);

                //Check Result
                if (!strComparison.first)
                {
                    match = false;
                    break;
                }

                //Reconstruct the string found
                strFound.append(" ");
                strFound.append(strComparison.second);
            }

            if (match)
            {
                int strIndex = 0; 

                for (int k = 0; k < i; ++k)
                {
                    strIndex += static_cast<int>(cardTextAsWords[k].length());
                    strIndex += 1;  //To account for the whitespace " " between words
                }

                return strIndex;
            }
        }
    }


    return 0;
}

inline std::pair<bool, std::string> SetSearcher::compareStr(std::string str1, std::string str2, std::string cardName)
{
    bool checkNumbers = false;

    const int numNumbers = 2 * 21;
    std::string numbers[numNumbers] = {"zero", "one", "two" ,"three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty",
                                           "0", "1", "2",  "3",  "4",  "5",  "6",  "7",  "8",  "9",  "10",  "11",  "12",  "13",  "14",  "15",  "16",  "17",  "18",  "19",  "20"};

    //Check for context relevant strings - NO LONGER NEEDED AS REPLACEMENT OCCURS IN searchCardTextForStr
    //if (str1 == "_CARD_NAME")
    //{     
    //    std::vector<std::string> cardNameVec = strToVec(cardName);
    //
    //    bool match = false;
    //
    //    for (size_t i = 0; i < cardNameVec.size(); ++i)
    //    {
    //        if (str2 == cardNameVec[i])
    //        {
    //            match = true;
    //            str2 = cardNameVec[i];
    //            break;
    //        }
    //    }
    //
    //    return std::pair<bool, std::string>(match, str2);
    //}
    if (str1 == "_NUMBER")
    {
        //Check if string matches number
        for (int i = 0; i < numNumbers; ++i)
        {
            if (str2 == numbers[i])
            {
                return std::pair<bool, std::string>(true, numbers[i]);
            }
        }
        //No matching number found
        return std::pair<bool, std::string>(false, "");
    }
    else if (str1 == "_MANA_ACTIVATED_ABILITY")
    {
        if (str2[0] == '{' && str2.back() == ':' && str2[str2.length() - 2] == '}')
        {
            //Check it's not a Tap acitvated ability
            std::string XCost = str2.substr(1, str2.find('}') - 1); //The cost to acticate this ability (T == Tap), (Number == Mana Cost)

            if (XCost != "T")
            {
                return std::pair<bool, std::string>(true, XCost);
            }
        }
        return std::pair<bool, std::string>(false, "");
    }
    else if (str1 == "_TAP_ACTIVATED_ABILITY")
    {
        if (str2 == "{T}:")
        {
            return std::pair<bool, std::string>(true, str2);
        }
        return std::pair<bool, std::string>(false, "");
    }
    else if (str1 == "_ACTIVATED_ABILITY")
    {
        if (str2[0] == '{' && str2.back() == ':' && str2[str2.length() - 2] == '}')
        {
            return std::pair<bool, std::string>(true, str2.substr(1, str2.find('}') - 1));
        }
        return std::pair<bool, std::string>(false, "");
    }

    else
    {
        //Normal compare
        return std::pair<bool, std::string>(str1 == str2, str2);
    }

#ifdef _DEBUG
    cerr << "Error: Went past if statements " << "SetSearcher" << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG		

    return std::pair<bool, std::string>(false, "");
}

std::vector<std::string> SetSearcher::strToVec(std::string str)
{
    std::vector<std::string> ret;

    if (str != "")
    {
        //Get first char of string
        std::string::iterator it1 = str.begin();

        //Get next " "/whitespace char
        std::string::iterator it2 = it1;
        ++it2;
        bool stringEndFound = false;
        do
        {
            bool wordAdded = false;
            if (it2 == str.end())
            {
                stringEndFound = true;
                ret.push_back(str.substr(std::distance(str.begin(), it1), std::distance(it1, it2)));
                wordAdded = true;
            }
            else
            {

                //Keep iterating through string until " "/whitespace or "'\n"/new line is found
                if (*it2 == ' ' || *it2 == '\n' || *it2 == ',' || *it2 == '.')
                {
                    //Store substring in vec
                    ret.push_back(str.substr(std::distance(str.begin(), it1), std::distance(it1, it2)));
                    wordAdded = true;

                    //Find next char after " " that isn't " "
                    do
                    {
                        ++it2;
                        if (it2 == str.end())
                        {
                            stringEndFound = true;
                            break;
                        }
                    } while (*it2 == ' ' && !stringEndFound);
                    
                    it1 = it2;
                }
            }
            if (!wordAdded)
            {
                ++it2;
            }
        } while (!stringEndFound); //Repeat until end of str
    }
    else
    {
#ifdef _DEBUG
        //cerr << "Error: Empty string passed to " << "SetSearcher" << "::" << __func__ << "(), line" << __LINE__ << " file " << __FILE__ << "\n";
#endif // _DEBUG		
        return std::vector<std::string>();
    }
    return ret;
}
