#pragma once
class CardSkeleton
{
};

