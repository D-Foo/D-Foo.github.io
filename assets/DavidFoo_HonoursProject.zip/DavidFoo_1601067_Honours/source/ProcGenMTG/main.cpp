#include <iostream>
#include <SFML/Graphics.hpp>
#include "imgui.h"
#include "ImGui-SFML/imgui-SFML.h"
#include "SetParser.h"
#include "KeyboardInput.h"
#include "MouseInput.h"
#include "MTG_Structures.hpp"
#include "SetData.h"
#include <random>
#include "CardCreator.h"
#include "SetCreator.h"
#include "SetSearcher.h"
#include "PointBasedCalculator.h"
#define _DEBUG 

//Forward Declarations
struct SetList;

void handleEvents(sf::RenderWindow& window, KeyboardInput& kbInput, MouseInput& mouseInput, bool takeUserInput);
void handleInput(sf::RenderWindow& window, KeyboardInput& kbInput, MouseInput& mouseInput);
std::vector<SetList> createSetLists();
SetCreator::SetParams createSetParams(SetData& setData, PointBasedCalculator& pbc);
std::map<std::string, TallyStruct::CombinedTally> filterKeywords(std::map<std::string, TallyStruct::CombinedTally> keywordTally, std::array<std::string, MTGStruct::numKeywords> keywordFilter);
std::vector<Skeleton::CardSkeleton> createSetCardSkeletons();

struct SetList
{
    SetList(std::vector<std::string> pathNames)
    {
        for (auto& s : pathNames)
        {
            std::string temp = "Data/";
            temp.append(s);
            temp.append(".json");
            setPaths.push_back(temp);
        }
        numSets = static_cast<int>(setPaths.size());
    }
    int numSets;
    std::vector<std::string> setPaths;
};


int main()
{
    //Init
    bool takeInput = true;
    bool launchWindow = false;
    bool outputCards = false;
    bool outputKeywords = false;
    bool outputPowerPointData = true;
    KeyboardInput kbInput;
    MouseInput mInput;
    srand(unsigned(time(NULL)));
    std::vector<MTGStruct::Card> allCreatureCards;
    std::vector<MTGStruct::Card> allSpellCards;
    std::vector<MTGStruct::Card> allArtifactCards;
    std::array<std::string, 35> keywordList = {};   //Keywords recognized

    //TESTING SPELL CREATION
    CardCreator cC;

    CardCreator::SpellParams testParams[5];
    testParams[0].name = "TestSpell0";
    testParams[0].colour = MTGStruct::ColourIdentity::W;
    testParams[1].name = "TestSpell1";
    testParams[1].colour = MTGStruct::ColourIdentity::U;
    testParams[2].name = "TestSpell2";
    testParams[2].colour = MTGStruct::ColourIdentity::B;
    testParams[3].name = "TestSpell3";
    testParams[3].colour = MTGStruct::ColourIdentity::R;
    testParams[4].name = "TestSpell4";
    testParams[4].colour = MTGStruct::ColourIdentity::G;
   
    for (int i = 0; i < 5; ++i)
    {
        testParams[i].rarity = MTGStruct::Rarity::Common;
        MTGStruct::Card testSpell = cC.CreateSpell(testParams[i]);
        cout << MTGStruct::CardToString(testSpell) << "\n";
    }

    //Read in Sets
    std::vector<MTGStruct::Card> set;
    std::vector<SetList> setLists = createSetLists();
    SetList* chosenSetList = &setLists[1];
    std::vector<SetData> creatureSetData;
    std::vector<SetData> spellSetData;
    std::vector<SetData> artifactSetData;
    for (int i = 0; i < chosenSetList->numSets; ++i)
    {
        creatureSetData.push_back(SetData());
        spellSetData.push_back(SetData());
        artifactSetData.push_back(SetData());
    }
    SetData aggregatedCoreSetData;



    //Parse Sets
    SetParser setParser;

    std::vector<MTGStruct::Supertype> creatureSupertypes = { MTGStruct::Supertype::Creature,  MTGStruct::Supertype::ArtifactCreature, MTGStruct::Supertype::EnchantmentArtifactCreature, MTGStruct::Supertype::EnchantmentCreature, MTGStruct::Supertype::LandCreature };
    std::vector<MTGStruct::Supertype> spellSupertypes = { MTGStruct::Supertype::Instant, MTGStruct::Supertype::Sorcery };
    std::vector<MTGStruct::Supertype> artifactSupertypes = { MTGStruct::Supertype::Artifact};
    bool logCreatures = true;
    bool parseSpells = false;
    bool parseArtifacts = false;

    setParser.setOnlyParseMonoColouredCards(true);
    for (int i = 0; i < chosenSetList->numSets - 1; ++i)
    {
        const char* filepath = chosenSetList->setPaths[i].c_str();

        std::vector<MTGStruct::Card> setCreatureCards = setParser.parseSetJSON(filepath, &creatureSetData[i], false, false, creatureSupertypes);
        std::vector<MTGStruct::Card> setSpellCards;
        std::vector<MTGStruct::Card> setArtifactCards;
        if (parseSpells)
        {
            setSpellCards = setParser.parseSetJSON(filepath, &spellSetData[i], false, false, spellSupertypes);
        }
        if (parseArtifacts)
        {
            setArtifactCards  = setParser.parseSetJSON(filepath, &artifactSetData[i], false, false, artifactSupertypes);
        }
        if (outputKeywords)
        {
            creatureSetData[i].outputKeywordTallyData();
        }
        if (outputCards)
        {
            for (auto& c : setCreatureCards)
            {
                cout << MTGStruct::CardToString(c);
            }
        }
        //Log Creatures
        for (auto& c : setCreatureCards)
        {
            //Don't add card if already included from another set
            bool cardAlreadyLogged = false;
            
            //Check if card already logged
            for (auto& d : allCreatureCards)
            {
                if (d.name == c.name)
                {
                    cardAlreadyLogged = true;
                    break;
                }
            }

            if (!cardAlreadyLogged)
            {
                //Log Card
                allCreatureCards.push_back(c);
            }
        }

        //Log Spells
        if (parseSpells)
        {
            for (auto& c : setSpellCards)
            {
                //Don't add card if already included from another set
                bool cardAlreadyLogged = false;

                //Check if card already logged
                for (auto& d : allSpellCards)
                {
                    if (d.name == c.name)
                    {
                        cardAlreadyLogged = true;
                        break;
                    }
                }

                if (!cardAlreadyLogged)
                {
                    //Log Card
                    allSpellCards.push_back(c);
                }
            }
        }

        //Log Artifacts
        if (parseArtifacts)
        {
            for (auto& c : setArtifactCards)
            {
                //Don't add card if already included from another set
                bool cardAlreadyLogged = false;

                //Check if card already logged
                for (auto& d : allArtifactCards)
                {
                    if (d.name == c.name)
                    {
                        cardAlreadyLogged = true;
                        break;
                    }
                }

                if (!cardAlreadyLogged)
                {
                    //Log Card
                    allArtifactCards.push_back(c);
                }
            }
        }
    }

    //Search for vanilla creatures
    SetSearcher setSearcher;
    std::vector<MTGStruct::Card> vanillaCreatures = setSearcher.getVanillaCreatures(allCreatureCards);
    std::vector<MTGStruct::Card> zeroPowerVanillaCreatures = setSearcher.filterToTargetPower(vanillaCreatures, 0);
    
    //Filter to creatures with 1 keyword
    std::vector<MTGStruct::Card> singleKeywordCreatures = setSearcher.filterToCreatures(allCreatureCards);
    singleKeywordCreatures = setSearcher.filterByNumKeywords(singleKeywordCreatures, 1);
    std::vector<MTGStruct::Card> onlyKeywordCreatures = setSearcher.filterToKeywordOnly(singleKeywordCreatures);
    std::vector<MTGStruct::Card> nonCreatureArtifacts = setSearcher.filterOutCreatures(allArtifactCards);
    std::vector<MTGStruct::Card> activatedArtifacts = setSearcher.filterToActivatedArtifacts(nonCreatureArtifacts);
    std::vector<MTGStruct::Card> equipmentCards = setSearcher.filterToEquipment(allArtifactCards);

    std::vector<std::tuple<std::string, int, MTGStruct::ColourIdentity>> followOnTextETB = setSearcher.getFollowOnTextToString(allCreatureCards, "When _CARD_NAME enters the battlefield");
    std::vector<std::string> ETBNames;
    for (auto& p : followOnTextETB)
    {
        //cout << "Follow On: " << std::get<0>(p) << " - " << std::get<1>(p) << " times, In colour " << MTGStruct::ColourIdentityToName(std::get<2>(p)) << ".\n";
        ETBNames.push_back(std::get<0>(p));
    }

    //Filter out card effects that won't make sense on procedurally generated cards
    std::vector<MTGStruct::Card> filteredCardText = setSearcher.filterByCardText(allCreatureCards, "named", false, true);
    filteredCardText = setSearcher.filterByCardText(filteredCardText, "Turret Ogre", false, true);
    filteredCardText = setSearcher.filterByCardText(filteredCardText, "Werewolf", false, true);

    std::vector<std::pair<MTGStruct::Card, std::string>> cardTextCreaturesAndCardText = setSearcher.filterByLeadInText(filteredCardText, "When _CARD_NAME enters the battlefield", MTGStruct::keywordList);

   

    std::vector<MTGStruct::Card> drawCardSpells = setSearcher.filterByCardText(allSpellCards, "Draw _NUMBER cards.", true);
    std::vector<MTGStruct::Card> dmgSpells = setSearcher.filterByCardText(allSpellCards, "_CARD_NAME deals _NUMBER damage to any target.", true);

    //Calculate point costs of power + toughness, keywords and card effects
    PointBasedCalculator pbc;
    pbc.setVanillaCards(&vanillaCreatures);
    pbc.setKeywordCards(&onlyKeywordCreatures);
    pbc.setCardTextCards(&cardTextCreaturesAndCardText);
    pbc.run();

    //Aggregate Set Data
    aggregatedCoreSetData = creatureSetData[0].combineWithSet(&creatureSetData[1]);
    for (int i = 2; i < chosenSetList->numSets; ++i)
    {
        aggregatedCoreSetData = aggregatedCoreSetData.combineWithSet(&creatureSetData[i]);
    }
    if (outputKeywords)
    {
        aggregatedCoreSetData.outputKeywordTallyData();
    }

    aggregatedCoreSetData.createKeywordColourWeights();

    //Output power point costs
    if (outputPowerPointData)
    {
        std::string colours[5] = { "White", "Blue", "Black", "Red", "Green"};
        cout << "Power Point Costs:\n";
        for (int i = 0; i < 5; ++i)
        {

            cout << colours[i] << ": " << pbc.getPointData().powerPointCost[i] << "\n";
        }
        cout << "\n";
    }


    //Create Set
    SetCreator setCreator;
    SetCreator::SetParams setParams = createSetParams(aggregatedCoreSetData, pbc);
    setParams.cardSkeletons = createSetCardSkeletons();
    std::vector<MTGStruct::Card> createdSet = setCreator.createSet(setParams, &aggregatedCoreSetData);
    setParser.saveXML(createdSet, "PROCGEN");

    //Ouput cards
    for (auto& c : createdSet)
    {
        cout << MTGStruct::CardToString(c);
    }

    //App Loop
    if (launchWindow)
    {
        sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Window");
        ImGui::SFML::Init(window);

        sf::Clock clock;
        while (window.isOpen())
        {
            handleEvents(window, kbInput, mInput, takeInput);

            handleInput(window, kbInput, mInput);

            ImGui::SFML::Update(window, clock.restart());

            ImGui::Begin("Hello, world!");
            ImGui::Button("WOwOW");
            ImGui::End();



            window.clear();
            ImGui::SFML::Render(window);
            window.display();
        }

        ImGui::SFML::Shutdown();
    }


    cout << "Press Enter to Quit...\n";
    cin.get();

    return 0;
}



void handleInput(sf::RenderWindow& window, KeyboardInput& kbInput, MouseInput& mInput)
{
    if (kbInput.onKeyDown(sf::Keyboard::Key::Escape))
    {
        window.close();
    }
}

std::vector<SetList> createSetLists()
{
    //0 - Core Sets M10-15 + ORI + Core19-21 
    //1 - Core + Expansions
   
    std::vector<SetList> ret;

    std::vector<std::string> coreNames = { "M10", "M11", "M12", "M13", "M14", "M15", "ORI", "M19", "M20", "M21" };
    SetList core(coreNames);
    ret.push_back(core);

    std::vector<std::string> coreExpanNames = {"M10", "M11", "M12", "M13", "M14", "M15", "ORI", "M19", "M20", "M21", "ISD", "DKA", "AVR", "SOI", "EMN", "KTK" , "FRF" , "DTK" , "OGW" , "KLD" , "AER" , "AKH" , "HOU" , "XLN" , "RIX" , "DOM" , "GRN" , "RNA" , "WAR" , "ELD" , "THB" , "IKO" , "ZNR"};
    SetList coreExpan(coreExpanNames);
    ret.push_back(coreExpan);
   

    return ret;
}

SetCreator::SetParams createSetParams(SetData& setData, PointBasedCalculator& pbc)
{
    SetCreator::SetParams ret;
    PointBasedCalculator::PointData pointData = pbc.getPointData();

    MTGStruct::ColourIdentity colourTable[6] = { MTGStruct::ColourIdentity::W, MTGStruct::ColourIdentity::U , MTGStruct::ColourIdentity::B ,MTGStruct::ColourIdentity::R , MTGStruct::ColourIdentity::G, MTGStruct::ColourIdentity::Colourless };

    //Evenly distribute among 5 colours
    for (int i = 0; i < 5; ++i)
    {
        ret.colourDistribution[i] = 20;
    }

    ret.keywordCosts = pointData.keywordCosts;
    ret.keywordTally = filterKeywords(*setData.getKeywordTally(), MTGStruct::keywordList);

    ret.cardTexts = pbc.getCardTexts();

    //Assign number of cards per mana cost
    for (int i = 0; i < 8; ++i)
    {
        if (i == 0) { ret.manaCostDistribution[i] = 0; }
        if (i >=1 && i <= 5) { ret.manaCostDistribution[i] = 16; }
        if (i == 6) { ret.manaCostDistribution[i] = 10; }
        if (i >= 7 && i <= 8) { ret.manaCostDistribution[i] = 5; }
    }
    ret.mythicPercent = 0;  //%Chance of a card being mythic
    ret.numCards = 250;     //Total number of cards to make this set

    constexpr float numCardsPerBooster = 14.0f;
    for (int i = 0; i < 4; ++i)
    {
        if (i == 0) { ret.rarityDistribution[i] = 10.0f / numCardsPerBooster; }  //Common %
        if (i == 1) { ret.rarityDistribution[i] = 3.0f / numCardsPerBooster; } //Uncommon %
        if (i == 2) { ret.rarityDistribution[i] = 0.875f / numCardsPerBooster; } //Rare %
        if (i == 3) { ret.rarityDistribution[i] = 0.125f / numCardsPerBooster; }  //Mythic %
    }


    //Get point data from the point calculator
    ret.pointsPerManaCost = pbc.getPointsPerManaCost();
    for (int i = 0; i < 5; ++i)
    {
        ret.powerPointCosts[i] = pointData.powerPointCost[i];
        ret.toughnessPointCosts[i] = pointData.toughnessPointCost[i];
        ret.PTRatio[i] = pbc.getPTRatio(colourTable[i]);
    }

    std::array<float, MTGStruct::numRarities> pointRarityMultipliers = { 1.15f, 1.2f, 1.3f, 1.5f };
    for (int i = 0; i < 4; ++i)
    {
        ret.rarityPointMultiplier[i] = pointRarityMultipliers[i];    //All rarities have the same point multiplier
    }
    ret.subtypeTally = *setData.getSubtypeTally();

    return ret;
}

std::map<std::string, TallyStruct::CombinedTally> filterKeywords(std::map<std::string, TallyStruct::CombinedTally> keywordTally, std::array<std::string, MTGStruct::numKeywords> keywordFilter)
{
    //Filters keywordTally by removing elements not in the filter
    for (std::map<std::string, TallyStruct::CombinedTally>::iterator it = keywordTally.begin(); it != keywordTally.end();)
    {
        bool keywordFound = false;
        for (int i = 0; i < MTGStruct::numKeywords; ++i)
        {
            if ((*it).first == keywordFilter[i])
            {
                keywordFound = true;
            }
        }
        if (!keywordFound)
        {
            it = keywordTally.erase(it);
        }
        else
        {
            ++it;
        }
    }
    return keywordTally;
}

std::vector<Skeleton::CardSkeleton> createSetCardSkeletons()
{
    // Add SetStaples to ret here
    std::vector<Skeleton::CardSkeleton> ret;
    MTGStruct::ManaCost mc; 
    
    //White
    Skeleton::CardSkeleton cSkeletonW;
    cSkeletonW.cardTextToAdd.push_back("First Strike");
    cSkeletonW.power = 1;
    cSkeletonW.toughness = 1;
    mc.white = 1;
    cSkeletonW.manaCost = mc;
    cSkeletonW.supertype = MTGStruct::Supertype::Creature;
    cSkeletonW.subtypes.push_back("Human");
    cSkeletonW.cI = MTGStruct::ColourIdentity::W;

    mc = MTGStruct::ManaCostZero;

    //Blue
    Skeleton::CardSkeleton cSkeletonU;
    cSkeletonU.cardTextToAdd.push_back("When _CARD_NAME enters the battlefield, return another target creature to its owners hand.");
    cSkeletonU.power = 2;
    cSkeletonU.toughness = 2;
    mc.blue = 1;
    mc.generic = 2;
    cSkeletonU.manaCost = mc;
    cSkeletonU.supertype = MTGStruct::Supertype::Creature;
    cSkeletonU.subtypes.push_back("Vedalken");
    cSkeletonU.cI = MTGStruct::ColourIdentity::U;

    mc = MTGStruct::ManaCostZero;

    //Black

    //Red

    //Green Staple Elf
    Skeleton::CardSkeleton cSkeletonG;
    cSkeletonG.cardTextToAdd.push_back("{T}: Add {G} to your mana pool.");
    cSkeletonG.power = 1;
    cSkeletonG.toughness = 1;
    mc.green = 1;
    cSkeletonG.manaCost = mc;
    cSkeletonG.supertype = MTGStruct::Supertype::Creature;
    cSkeletonG.subtypes.push_back("Elf");
    cSkeletonG.cI = MTGStruct::ColourIdentity::G;

    mc = MTGStruct::ManaCostZero;

    ret.push_back(cSkeletonW);
    ret.push_back(cSkeletonU);
    ret.push_back(cSkeletonG);
    return ret;
}

void handleEvents(sf::RenderWindow& window, KeyboardInput& kbInput, MouseInput& mInput, bool takeUserInput)
{
    sf::Event event;
    while (window.pollEvent(event))
    {
        ImGui::SFML::ProcessEvent(event);

        switch (event.type)
        {
        case sf::Event::Closed:
            window.close();
            break;
        case sf::Event::Resized:
            window.setView(sf::View(sf::FloatRect(0, 0, event.size.width, event.size.height)));
            break;
        case sf::Event::KeyPressed:
            if (takeUserInput)
            {
                kbInput.setKeyDown(event.key.code);
            }
            break;
        case sf::Event::KeyReleased:
            if (takeUserInput)
            {
                kbInput.setKeyUp(event.key.code);
            }
            break;
        case sf::Event::MouseMoved:
            mInput.setXY(event.mouseMove.x, event.mouseMove.y);
            break;
        case sf::Event::MouseButtonPressed:
            if (event.mouseButton.button == sf::Mouse::Right)
            {
                mInput.setRight(true);
            }
            else if (event.mouseButton.button == sf::Mouse::Left)
            {
                mInput.setLeft(true);
            }
            break;
        case sf::Event::MouseButtonReleased:
            if (event.mouseButton.button == sf::Mouse::Right)
            {
                mInput.setRight(false);
            }
            else if (event.mouseButton.button == sf::Mouse::Left)
            {
                mInput.setLeft(false);
            }
            break;

        }
    }
}

