#include "MouseInput.h"



MouseInput::MouseInput()
{
	left = false;
	middle = false; 
	right = false;

	x = 0;
	y = 0;
}


MouseInput::~MouseInput()
{
}
