#pragma once
#include <string>
#include <vector>
#include <iostream>
#include <array>

using std::cerr;

namespace MTGStruct
{
	//Utility Variables
	static constexpr int manaCostCap = 16;//The card with the highest CMC is Draco at 16
	static constexpr int numKeywords = 35;
	static std::array<std::string, numKeywords> keywordList = { "Deathtouch", "Defender", "Double Strike" , "First Strike" , "Flash" , "Flying" , "Haste" , "Hexproof" , "Shroud" , "Indestructible" , "Lifelink" , "Menace" , "Reach", "Trample", "Vigilance", "Battle Cry", "Cascade", "Convoke", "Dethrone", "Evolve", "Exalted", "Fear", "Infect", "Improvise", "Intimidate", "Persist", "Prowess", "Undying", "Wither", "Delve", "Forestwalk", "Swampwalk", "Mentor", "Riot", "Skulk" };;

	//---Enums---
	enum class Colours {White, Blue, Black, Red, Green};
	static Colours StringToColour(std::string str)
	{
		std::string strs[5] = {"White", "Blue", "Black", "Red", "Green" };
		for (int i = 0; i < 5; ++i)
		{
			if (str == strs[i])
			{
				return static_cast<Colours>(i);
			}
		}
	}

	//-Colour Identity-
	static constexpr int numColourIdentities = 32;
	enum class ColourIdentity {Colourless, W, U, B, R, G, WU, WB, WR, WG, UB, UR, UG, BR, BG, RG, WUB, WUR, WUG, WBR, WBG, WRG, UBR, UBG, URG, BRG, WUBR, WBRG, UBRG, WUBG, WURG, WUBRG};
	//Utility Functions
	static ColourIdentity StringToColourIdentity(std::string str)
	{
		std::string strs[numColourIdentities] = { "Colourless", "W", "U", "B", "R", "G", "WU", "WB", "WR", "WG", "UB", "UR", "UG", "BR", "BG", "RG", "WUB", "WUR", "WUG", "WBR", "WBG", "WRG", "UBR", "UBG", "URG", "BRG", "WUBR", "WBRG", "UBRG", "WUBG", "WURG", "WUBRG" };
		for (int i = 0; i < numColourIdentities; ++i)
		{
			if (str == strs[i])
			{
				return static_cast<ColourIdentity>(i);
			}
		}
#ifdef _DEBUG
		cerr << "Could not find ColourIdentity in StringToColourIdentity()\n";
#endif // _DEBUG	
		return ColourIdentity::Colourless;
	}

	static std::string ColourIdentityToName(ColourIdentity ci)
	{
		std::string colourIdentities[numColourIdentities] = { "Colourless", "White", "Blue", "Black", "Red", "Green", "Azorius", "Orzhov", "Boros", "Selesnya", "Dimir", "Izzet", "Simic", "Rakdos", "Golgari", "Gruul", "Esper", "Jeskai", "Bant", "Mardu", "Abzan", "Naya", "Grixis", "Sultai", "Temur", "Jund", "Yore", "Dune", "Glint", "Witch", "Ink", "Five Colour" };
		return colourIdentities[static_cast<int>(ci)];
	}

	static ColourIdentity ColourIdentityFromParts(bool W, bool U, bool B, bool R, bool G)
	{
		std::string ci = "";
		if (W) { ci.append("W"); }
		if (U) { ci.append("U"); }
		if (B) { ci.append("B"); }
		if (R) { ci.append("R"); }
		if (G) { ci.append("G"); }
		if (!W && !U && !B && !R && !G) { ci = "Colourless"; }

		return StringToColourIdentity(ci);
	}
	static void PartsFromColourIdentity(bool& W, bool& U, bool& B, bool& R, bool& G, ColourIdentity ci)
	{
		W = false; U = false; B = false; R = false; G = false;
		
		if (ci == ColourIdentity::Colourless)
		{
			return;
		}
		
		std::string strs[numColourIdentities] = { "Colourless", "W", "U", "B", "R", "G", "WU", "WB", "WR", "WG", "UB", "UR", "UG", "BR", "BG", "RG", "WUB", "WUR", "WUG", "WBR", "WBG", "WRG", "UBR", "UBG", "URG", "BRG", "WUBR", "WBRG", "UBRG", "WUBG", "WURG", "WUBRG" };

		std::string str = strs[static_cast<int>(ci)];
		for (size_t i = 0; i < str.size(); ++i)
		{
			switch (str[i])
			{
			case('W'):
				W = true;
				break;
			case('U'):
				U = true;
				break;
			case('B'):
				B = true;
				break;
			case('R'):
				R = true;
				break;
			case('G'):
				G = true;
				break;
			}
		}
	}
	
	static std::string ColourIdentityToWUBRG(ColourIdentity ci)
	{
		bool W; bool U; bool B; bool R; bool G;
		PartsFromColourIdentity(W, U, B, R, G, ci);
		std::string ret = "";
		if (W) { ret.append("W"); }
		if (U) { ret.append("U"); }
		if (B) { ret.append("B"); }
		if (R) { ret.append("R"); }
		if (G) { ret.append("G"); }
		//if (!W && !U && !B && !R && !G) { ret = "Colourless"; }
		return ret;
	}

	//-Supertype-
	static constexpr int numSupertypes = 14;
	enum class Supertype {Artifact, Creature, Enchantment, Land, Planeswalker, ArtifactLand, ArtifactCreature, EnchantmentArtifact, EnchantmentArtifactCreature, EnchantmentCreature, EnchantmentLand, LandCreature, Instant, Sorcery};
	//Utility Functions
	static std::string SupertypeToString(Supertype supertype)
	{
		std::string supertypes[numSupertypes] = { "Artifact", "Creature", "Enchantment", "Land", "Planeswalker", "ArtifactLand", "ArtifactCreature", "EnchantmentArtifact", "EnchantmentArtifactCreature", "EnchantmentCreature", "EnchantmentLand", "LandCreature", "Instant", "Sorcery" };
		return supertypes[static_cast<int>(supertype)];
	}

	static Supertype StringToSupertype(std::string str)
	{
		std::string strs[numSupertypes] = { "Artifact", "Creature", "Enchantment", "Land", "Planeswalker", "ArtifactLand", "ArtifactCreature", "EnchantmentArtifact", "EnchantmentArtifactCreature", "EnchantmentCreature", "EnchantmentLand", "LandCreature", "Instant", "Sorcery" };
		for (int i = 0; i < numSupertypes; ++i)
		{
			if (str == strs[i])
			{
				return static_cast<Supertype>(i);
			}
		}
#ifdef _DEBUG
		cerr << "Could not find Supertype in StringToSupertype()\n";
#endif // _DEBUG	
		return Supertype::Artifact;
	}

	//-Rarity-
	static constexpr int numRarities = 4;
	enum class Rarity {Common, Uncommon, Rare, Mythic};
	//Utility Functions
	static Rarity StringToRarity(std::string str)
	{
		std::string strs[numRarities] = { "Common", "Uncommon", "Rare", "Mythic" };
		std::string JSONstrs[numRarities] = { "common", "uncommon", "rare", "mythic" };

		for (int i = 0; i < numRarities; ++i)
		{
			if (str == strs[i] || str == JSONstrs[i])
			{
				return static_cast<Rarity>(i);
			}
		}
#ifdef _DEBUG
		cerr << "Could not find Rarity in StringToRarity()\n";
#endif // _DEBUG	
		return Rarity::Common;
	}
	static std::string RarityToString(Rarity rarity)
	{
		std::string strs[numRarities] = { "Common", "Uncommon", "Rare", "Mythic" };
		return strs[static_cast<int>(rarity)];
	} 
	//---Structs---

	//Mana Cost
	struct ManaCost
	{
		//Number of symbols required for each part of the cost
		short unsigned int colourless = 0;
		short unsigned int white = 0;
		short unsigned int blue = 0;
		short unsigned int black = 0;
		short unsigned int red = 0;
		short unsigned int green = 0;
		short unsigned int generic = 0;
		int X = 0;	//Number of X's in casting cost
		bool noCastingCost = false;	//For cards that have no casting cost (NOT 0 cost cards)

		const bool operator== (ManaCost mc2) const
		{
			if (mc2.colourless == colourless && mc2.white == white && mc2.blue == blue && mc2.black == black &&
				mc2.red == red && mc2.green == green && mc2.generic == generic && mc2.X == X && mc2.noCastingCost == noCastingCost)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		const bool operator!=(ManaCost mc2) const 
		{
			return !(this->operator==(mc2));
		}

	};

	static const ManaCost ManaCostZero = ManaCost();
	
	static int ManaCostToCMC(ManaCost& mc)
	{
		if (mc.noCastingCost)
		{
			return -1;
		}

		return mc.colourless + mc.white + mc.blue + mc.black + mc.red + mc.green + mc.generic;
	}

	static void ManaCostAddWUBRG(ManaCost& mc, ColourIdentity colour, int amount)
	{
		switch (colour)
		{
		case MTGStruct::ColourIdentity::W:
			mc.white += amount;
			break;
		case MTGStruct::ColourIdentity::U:
			mc.blue += amount;
			break;
		case MTGStruct::ColourIdentity::B:
			mc.black += amount;
			break;
		case MTGStruct::ColourIdentity::R:
			mc.red += amount;
			break;	
		case MTGStruct::ColourIdentity::G:
			mc.green += amount;
			break;
		default:
			break;
		}
	}

	static std::string ManaCostToString(ManaCost& manaCost, bool brackets = true)
	{
		std::string ret;
		if (!manaCost.noCastingCost)
		{
			if (manaCost.X)
			{
				ret += "{";
				ret += "X";
				ret += "}";
			}

			if (manaCost.generic)
			{
				ret += "{";
				ret += std::to_string(manaCost.generic);
				ret += "}";
			}
			if (manaCost.white)
			{
				for (int i = 0; i < manaCost.white; ++i)
				{
					ret += "{W}";
				}
			}
			if (manaCost.blue)
			{
				for (int i = 0; i < manaCost.blue; ++i)
				{
					ret += "{U}";
				}
			}
			if (manaCost.black)
			{
				for (int i = 0; i < manaCost.black; ++i)
				{
					ret += "{B}";
				}
			}
			if (manaCost.red)
			{
				for (int i = 0; i < manaCost.red; ++i)
				{
					ret += "{R}";
				}
			}
			if (manaCost.green)
			{
				for (int i = 0; i < manaCost.green; ++i)
				{
					ret += "{G}";
				}
			}
			if (manaCost.colourless)
			{
				for (int i = 0; i < manaCost.colourless; ++i)
				{
					ret += "{C}";
				}
			}

		}

		if (!brackets)
		{
			for (std::string::iterator it = ret.begin(); it != ret.end(); )
			{
				if (*it == '{' || *it == '}')
				{
					it = ret.erase(it);
					if (it == ret.end())
					{
						break;
					}
				}
				else
				{
					++it;
				}
			}
		}

		return ret;
	}

	//Card
	struct Card
	{
		ColourIdentity colourIdentity = ColourIdentity::Colourless;
		ManaCost manaCost;
		short unsigned int CMC = 0;	//Short for converted mana cost
		std::string name = "nameNotSet";
		Supertype supertype = Supertype::Artifact;
		Rarity rarity;
		std::vector<std::string> subtypes;
		std::vector<std::string> keywords;
		bool standardPower = true;	//Whether or not to treat power as int
		bool standardToughness = true;	//Whether or not to treat toughness as int
		short unsigned int power = 0;
		short unsigned int toughness = 0;
		std::string cardText = "cardTextNotSet";
		std::string nonStandardPower = "";
		std::string nonStandardToughness = "";
	};

	static std::string CardToString(Card& card)
	{
		std::string ret = "Name: ";
		ret += card.name;
		if (card.CMC)
		{
			ret += "  -  ";
			ret += ManaCostToString(card.manaCost);
		}
		ret += "\n";
		ret += "CI: ";
		ret += ColourIdentityToName(card.colourIdentity);
		ret += " - ";
		ret += MTGStruct::RarityToString(card.rarity);
		ret += "\n";
		ret += SupertypeToString(card.supertype);
		if (!card.subtypes.empty())
		{
			ret += "  -  ";
			for (auto& st : card.subtypes)
			{
				ret += " ";
				ret += st;
			}
		}
		ret += "\n";
		ret += card.cardText;
		if (card.power || card.toughness)
		{
			ret += "\n";
			ret += "{";
			card.standardPower ? ret += std::to_string(card.power) : ret += card.nonStandardPower;
			ret += ", ";
			card.standardToughness ? ret += std::to_string(card.toughness) : ret += card.nonStandardToughness;
			ret += "}";
		}
		ret += "\n\n";
		
		return ret;
	}

}