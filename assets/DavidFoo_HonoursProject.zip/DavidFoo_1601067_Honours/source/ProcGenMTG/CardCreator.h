#pragma once
#include "MTG_Structures.hpp"
#include "Skeleton_Structures.hpp"
#include "SetData.h"

class CardCreator
{
public:

	CardCreator() { setData = nullptr; };

	struct CreatureParams
	{
		MTGStruct::ColourIdentity colour;
		MTGStruct::ManaCost manaCost;
		int CMC;
		MTGStruct::Supertype supertype;
		MTGStruct::Rarity rarity;
		float PT_Ratio;
		std::vector<std::pair<std::string, float>> potentialKeywords;	//pair<keyword, cost>
		std::vector<std::pair<std::string, float>>  potentialCardTexts;	//pair<effect, cost>
		std::vector<std::pair<std::string, TallyStruct::SubTypeData>> potentialSubtypes;
		float numPoints;
		float powerPointCost;
		float toughnessPointCost;
		std::string name;
		float pointMultiplier;
	
	};

	struct SpellParams
	{
		MTGStruct::ColourIdentity colour;
		MTGStruct::ManaCost manaCost;
		int CMC;
		bool isInstant;	//Instant if true, sorcery if not
		bool cantrips;	//Add a draw component to the card if true
		MTGStruct::Rarity rarity;
		std::string name;
	};

	struct EquipmentParams
	{
		MTGStruct::ColourIdentity colour;
		MTGStruct::ManaCost manaCost;
		int CMC;
		MTGStruct::Rarity rarity;
		std::string name;
	};


	//MTGStruct::Card CreateCard(MTGStruct::ColourIdentity colour, MTGStruct::ManaCost manaCost, MTGStruct::Supertype superType);
	void SetSetData(SetData* setData) { this->setData = setData; };
	MTGStruct::Card FillInCardSkeleton(Skeleton::CardSkeleton cardSkeleton, CreatureParams params, int pointsPerManaCost);
	MTGStruct::Card CreateSpell(SpellParams params);

private:

	SetData* setData;	
	MTGStruct::Card FillInCreatureSkeleton(Skeleton::CardSkeleton cardSkeleton, CreatureParams params, int pointsPerManaCost);
};

