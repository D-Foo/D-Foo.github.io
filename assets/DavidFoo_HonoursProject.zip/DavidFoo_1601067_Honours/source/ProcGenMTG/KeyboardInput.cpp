#include "KeyboardInput.h"



KeyboardInput::KeyboardInput()
{
	keys.fill(false);
	lastFrameKeys.fill(false);
}


KeyboardInput::~KeyboardInput()
{
}


void KeyboardInput::updateLastFrameKeys()
{
	lastFrameKeys = keys;
}

//Returns true if key was pressed on this frame
bool KeyboardInput::onKeyDown(sf::Keyboard::Key keyCode)
{
	if (keys[keyCode] && !lastFrameKeys[keyCode])
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool KeyboardInput::isKeyDown(sf::Keyboard::Key keyCode)
{
	if (keys[keyCode])
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool KeyboardInput::onKeyUp(sf::Keyboard::Key keyCode)
{
	if (!keys[keyCode] && lastFrameKeys[keyCode])
	{
		return true;
	}
	else
	{
		return false;
	}
}

void KeyboardInput::setKeyDown(sf::Keyboard::Key keyCode)
{
	keys[keyCode] = true;
}

void KeyboardInput::setKeyUp(sf::Keyboard::Key keyCode)
{
	keys[keyCode] = false;
}
