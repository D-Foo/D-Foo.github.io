#pragma once

//Handles mouse clicks
class MouseInput
{
public:
	MouseInput();
	~MouseInput();

	bool getLeft() { return left; };
	bool getMiddle() { return middle; };
	bool getRight() { return right; };

	void setLeft(bool state) { left = state; };
	void setMiddle(bool state) { middle = state; };
	void setRight(bool state) { right = state; };


	int getX() { return x; };
	int getY() { return y; };

	void setX(int pos) { x = pos; };
	void setY(int pos) { y = pos; };
	void setXY(int Xpos, int Ypos) { x = Xpos; y = Ypos; };
private:
	bool left, middle, right;
	int x, y;
};

