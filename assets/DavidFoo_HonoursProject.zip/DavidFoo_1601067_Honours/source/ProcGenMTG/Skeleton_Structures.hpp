#include "MTG_Structures.hpp"

namespace Skeleton
{
	//Mana Costs minimum and maximum inclusive { Small{MinCost, MaxCost}, Medium, Large }
	static const int manaCosts[3][2] = { {1, 2}, {3, 5}, {6, 8} };
	static const int numKeywordsToAdd[3][2] = { {0, 1}, {0, 2}, {1, 3} };
	
	enum class CreatureSize
	{
		NotSet, Small, Medium, Large
	};

	//CardSkeleton contains pieces pre filled in and sent to card creator to have rest of card created
	struct CardSkeleton
	{
		CardSkeleton()
		{
			supertype = MTGStruct::Supertype::Creature;
			keywords = std::vector<std::string>();
			cardTextToAdd = std::vector<std::string>();
			power = 0;
			toughness = 0;
			manaCost = MTGStruct::ManaCost();
			creatureSize = CreatureSize::NotSet;
			isVanilla = false;
			isFrenchVanilla = false;
			subtypes = std::vector<std::string>();
			cI = MTGStruct::ColourIdentity::Colourless;
			rarity = MTGStruct::Rarity::Common;
		}

		CardSkeleton(MTGStruct::Supertype supertype, std::vector<std::string> keywords, std::vector<std::string> cardTextToAdd, int power, int toughness, MTGStruct::ManaCost manaCost, CreatureSize creatureSize, bool isVanilla, bool isFrenchVanilla, std::vector<std::string> subtypes, MTGStruct::ColourIdentity cI, MTGStruct::Rarity rarity)
		{
			this->supertype = supertype;
			this->keywords = keywords;
			this->cardTextToAdd = cardTextToAdd;
			this->power = power;
			this->toughness = toughness;
			this->manaCost = manaCost;
			this->creatureSize = creatureSize;
			this->isVanilla = isVanilla;
			this->isFrenchVanilla = isFrenchVanilla;
			this->subtypes = subtypes;
			this->cI = cI;
			this->rarity = rarity;
		}

		MTGStruct::Supertype supertype;
		std::vector<std::string> keywords;
		std::vector<std::string> cardTextToAdd;
		int power;
		int toughness;
		MTGStruct::ManaCost manaCost;
		CreatureSize creatureSize;
		bool isVanilla;
		bool isFrenchVanilla;
		std::vector<std::string> subtypes;
		MTGStruct::ColourIdentity cI;
		MTGStruct::Rarity rarity;
	};

	//Configurable Weight Percentages
	struct ColourWeights
	{
		float typePercentages[MTGStruct::numSupertypes] = { 0 };	//Supertype Percentages for each supertype, should sum to 100
		std::vector<std::vector<std::pair<std::string, int>>> creatureKeywords;	//Keywords to be added to creatures in the set and how many common[0]/uncommon[1]/rare[2]/mythic[3] creatures should have those
																				//TODO: When assigning create vec of potential members that kw could be assigned to then pick one of them at random to assign it to

		std::vector<std::vector<std::pair<std::string, int>>> creatureText; //Text that should be a part of some spells in the set e.g. Divination for blue --Need to create text linking code before this can be implemented-- 

		std::vector<std::vector<std::pair<std::string, int>>> spellText; //Text that should be a part of some spells in the set e.g. Divination for blue --Need to create text linking code before this can be implemented-- 
		
		
	};
}