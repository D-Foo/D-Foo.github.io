#include "SetParser.h"

SetParser::SetParser()
{
	onlyParseMonoColouredCards = false;
	parseFuseOrFlipCards = false;
	onlyParseCreatures = false;
}

SetParser::~SetParser()
{
}

std::vector<MTGStruct::Card> SetParser::parseSetJSON(const char* filepath, SetData* setData, bool outputIncorrectlyLoadedCards, bool storeIncorrectlyLoadedCards, std::vector<MTGStruct::Supertype> supertypes)
{
	bool loadFlag = true;

	std::vector<MTGStruct::Card> ret;

	rapidjson::Document doc;

	cout << "Loading JSON Data from \"" << filepath << "\"\n";

	//Load JSON 
	std::string json = loadJSON(filepath);

	cout << "Parsing JSON Data\n";

	doc.Parse(json.c_str());
	//Check if loadedCorrectly
	if (!doc.IsObject())
	{
		cerr << "Failed to parse\n";
		loadFlag = false;
		return ret;
	}

	//Load in texture atlas and subtextures
	bool loadedCorrectly = loadSetFromJSON(doc, ret, setData, outputIncorrectlyLoadedCards, storeIncorrectlyLoadedCards, supertypes);
	
	loadFlag = loadedCorrectly;

	//If loaded correctly return texture atlas
	if (loadFlag)
	{
		return ret;
	}
	else
	{
		return std::vector<MTGStruct::Card>();
	}
}

void SetParser::saveXML(std::vector<MTGStruct::Card>& cards, std::string setName)
{
	bool test = false;
	if (test)
	{
		pugi::xml_document doc;

		pugi::xml_node node = doc.append_child("node");

		// add description node with text child
		pugi::xml_node descr = node.append_child("description");
		descr.append_child(pugi::node_pcdata).set_value("Simple node");

		// add param node before the description
		pugi::xml_node param = node.insert_child_before("param", descr);

		// add attributes to param node
		param.append_attribute("name") = "version";
		param.append_attribute("value") = 1.1;
		param.insert_attribute_after("type", param.attribute("name")) = "float";
		// end::code[]

		doc.print(std::cout);

		std::cout << "\nSaving result: " << doc.save_file("pugiTEST.xml") << std::endl;
	}
	else
	{
		//Create Doc
		pugi::xml_document doc;

		//Doc Declaration
		pugi::xml_node decl = doc.prepend_child(pugi::node_declaration);
		decl.append_attribute("version") = "1.0";
		decl.append_attribute("encoding") = "UTF-8";

		//Cockatrice Set Data
		pugi::xml_node cockatriceCardDBNode = doc.append_child("cockatrice_carddatabase");
		cockatriceCardDBNode.append_attribute("version") = "4";

		pugi::xml_node setsNode = cockatriceCardDBNode.append_child("sets");
		pugi::xml_node setNode = setsNode.append_child("set");
		pugi::xml_node name = setNode.append_child(setName.c_str());
		name.append_child(pugi::node_pcdata).set_value("GEN");
		pugi::xml_node longname = setNode.append_child("longname");
		longname.append_child(pugi::node_pcdata).set_value("Magic: the Procedurally Generated");
		pugi::xml_node settype = setNode.append_child("settype");
		settype.append_child(pugi::node_pcdata).set_value("Custom");
		pugi::xml_node releaseDate = setNode.append_child("releasedate");
		releaseDate.append_child(pugi::node_pcdata).set_value("2021-03-09");

		//Card Data
		pugi::xml_node cardsNode = cockatriceCardDBNode.append_child("cards");

		for (auto& c : cards)
		{
			//<card>
			pugi::xml_node cardNode = cardsNode.append_child("card");

			//<name>
			pugi::xml_node cardName = cardNode.append_child("name");
			cardName.append_child(pugi::node_pcdata).set_value(c.name.c_str());

			//<text>
			pugi::xml_node cardText = cardNode.append_child("text");
			std::string cardTextString = "";
			if (c.keywords.size() > size_t(0))
			{
				for (auto& kw : c.keywords)
				{
					cardTextString += kw;
					cardTextString += ", ";
				}

				cardTextString.erase(cardTextString.length() - 1, 2);

				cardTextString += "\n";
			}
			cardTextString += c.cardText;

			cardText.append_child(pugi::node_pcdata).set_value(cardTextString.c_str());

			//<prop>
			pugi::xml_node propNode = cardNode.append_child("prop");

			//<layout>
			pugi::xml_node layoutNode = propNode.append_child("layout");
			layoutNode.append_child(pugi::node_pcdata).set_value("normal");

			//<side>
			pugi::xml_node sideNode = propNode.append_child("side");
			sideNode.append_child(pugi::node_pcdata).set_value("front");
			
			//<type>
			pugi::xml_node mainTypeNode = propNode.append_child("maintype");
			mainTypeNode.append_child(pugi::node_pcdata).set_value(MTGStruct::SupertypeToString(c.supertype).c_str());

			std::string typeLine = MTGStruct::SupertypeToString(c.supertype);
			if (c.subtypes.size() > size_t(0))
			{
				typeLine += " - ";

				for (auto& st : c.subtypes)
				{
					typeLine.append(st);
					typeLine.append(" ");
				}

				typeLine.erase(typeLine.length() - 1, 1);	//Remove last " " in string

			}
			pugi::xml_node subtypeNode = propNode.append_child("type");
			subtypeNode.append_child(pugi::node_pcdata).set_value(typeLine.c_str());
			
			//<manacost>
			pugi::xml_node cardManaCost = propNode.append_child("manacost");
			cardManaCost.append_child(pugi::node_pcdata).set_value(MTGStruct::ManaCostToString(c.manaCost, false).c_str());

			//<cmc>
			pugi::xml_node cardCMC = propNode.append_child("cmc");
			cardCMC.append_child(pugi::node_pcdata).set_value(std::to_string(c.CMC).c_str());


			//<color>
			pugi::xml_node cardColour = propNode.append_child("color");
			cardColour.append_child(pugi::node_pcdata).set_value(MTGStruct::ColourIdentityToWUBRG(c.colourIdentity).c_str());

			//<coloridentity>

			//<pt> If creature add power toughness 
			if (c.supertype == MTGStruct::Supertype::Creature || c.supertype == MTGStruct::Supertype::ArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentArtifactCreature || c.supertype == MTGStruct::Supertype::EnchantmentCreature || c.supertype == MTGStruct::Supertype::LandCreature)
			{
				pugi::xml_node cardPT = propNode.append_child("pt");
				std::string ptLine;
				if (c.standardPower)
				{
					ptLine += std::to_string(c.power);
				}
				else
				{
					ptLine += c.nonStandardPower;
				}
				ptLine += "/";
				if (c.standardToughness)
				{
					ptLine += std::to_string(c.toughness);
				}
				else
				{
					ptLine += c.nonStandardToughness;
				}
				cardPT.append_child(pugi::node_pcdata).set_value(ptLine.c_str());
			}

			//</prop>

			//<set rarity = "">
			pugi::xml_node cardSet = cardNode.append_child("set");
			std::string rarityString = MTGStruct::RarityToString(c.rarity);
			for (auto& c : rarityString)
			{
				c = std::tolower(c);
			}
			cardSet.append_attribute("rarity") = rarityString.c_str();
			cardSet.append_child(pugi::node_pcdata).set_value("GEN");
		}

		//doc.print(std::cout);

		std::string fileName = setName;
		fileName.append(".xml");
		std::cout << "\nSaving result: " << doc.save_file(fileName.c_str()) << std::endl;
	}
}

void SetParser::setOnlyParseMonoColouredCards(bool parseMono)
{
	onlyParseMonoColouredCards = parseMono;
}

bool SetParser::loadSetFromJSON(rapidjson::Document& doc, std::vector<MTGStruct::Card>& set, SetData* setData, bool outputIncorrectlyLoadedCards, bool storeIncorrectlyLoadedCards, std::vector<MTGStruct::Supertype> supertypes)
{
	cout << "Checking for cards\n";

	//Navigate through JSON cards array
	if (!doc.HasMember("data")) { return false; }
	
	if (!doc["data"].HasMember("cards")) { return false; }
	if (!doc["data"]["cards"].IsArray()) { return false; }

	cout << "Loading card data\n";

	//Iterate through cards
	const rapidjson::Value& cardArray = doc["data"]["cards"];
	for (rapidjson::SizeType i = 0; i < cardArray.Size(); i++)
	{
		//Load in cards from JSON
		MTGStruct::Card card;
		if (loadCardFromJSON(doc, cardArray[i], card, supertypes) || storeIncorrectlyLoadedCards)
		{
			set.push_back(card);
			storeCardDataInSetData(&card, setData);
		}
		else
		{
			if (outputIncorrectlyLoadedCards)
			{
				cout << MTGStruct::CardToString(card);
			}
		}
	}

	if (!doc["data"].HasMember("baseSetSize")) { return false; }
	if (!doc["data"]["baseSetSize"].IsNumber()) { return false; }
	setData->setSetSize(doc["data"]["baseSetSize"].GetInt());

	if (!doc["data"].HasMember("code")) { return false; }
	if (!doc["data"]["code"].IsString()) { return false; }
	std::string temp = (doc["data"]["code"].GetString());

	temp = temp.substr(static_cast<size_t>(0), temp.find('"', static_cast<size_t>(1)));

	setData->setSetName(temp);

	return true;
}


bool SetParser::loadCardFromJSON(rapidjson::Document& doc, const rapidjson::Value& cardData, MTGStruct::Card& card, std::vector<MTGStruct::Supertype> supertypes)
{
	//Name
	if (!cardData.HasMember("name")) { return false; }
	if (!cardData["name"].IsString()) { return false; }
	card.name = cardData["name"].GetString();

	//If not parsing fuse/flip
	if (!parseFuseOrFlipCards)
	{
		//Check for // in card name, return false if found
		if (card.name.find("//") != std::string::npos)
		{
			return false;
		}
	}

	//Rarity
	if (!cardData.HasMember("rarity")) { return false; }
	if (!cardData["rarity"].IsString()) { return false; }
	MTGStruct::Rarity rarity = MTGStruct::StringToRarity(cardData["rarity"].GetString());
	card.rarity = rarity;

	//Colour Identity
	if (!cardData.HasMember("colorIdentity")) { return false; }
	if (!cardData["colorIdentity"].IsArray()) { return false; }

	bool W = false; bool U = false;	bool B = false;	bool R = false;	bool G = false;

	for (rapidjson::SizeType i = 0; i < cardData["colorIdentity"].Size(); i++)
	{
		switch (static_cast<char>(cardData["colorIdentity"][i].GetString()[0]))
		{
		case('W'):
			W = true;
			break;
		case('U'):
			U = true;
			break;
		case('B'):
			B = true;
			break;
		case('R'):
			R = true;
			break;
		case('G'):
			G = true;
			break;
		}
	}
	card.colourIdentity = MTGStruct::ColourIdentityFromParts(W, U, B, R, G);

	if (onlyParseMonoColouredCards)
	{	//Check if monoColoured
		if (card.colourIdentity == MTGStruct::ColourIdentity::W || card.colourIdentity == MTGStruct::ColourIdentity::U || card.colourIdentity == MTGStruct::ColourIdentity::B || card.colourIdentity == MTGStruct::ColourIdentity::R || card.colourIdentity == MTGStruct::ColourIdentity::G || card.colourIdentity == MTGStruct::ColourIdentity::Colourless)
		{
			//Continue
		}
		else
		{
			//TODO: Replace return with enum with a multiColour card found when mono is on
			return false;
		}
	}

	//Supertype(s)
	if (!cardData.HasMember("types")) { return false; }
	if (!cardData["types"].IsArray()) { return false; }
	if (!cardData["types"][0].IsString()) { return false; }
	std::string supertypeString = cardData["types"][0].GetString();
	for (rapidjson::SizeType i = 1; i < cardData["types"].Size(); i++)
	{
		if (!cardData["types"][i].IsString()) { return false; }
		supertypeString += cardData["types"][i].GetString();
	}

	card.supertype = MTGStruct::StringToSupertype(supertypeString);

	//Log colour Identity in Set Data
	//if (onlyParseCreatures)	Check no longer relevant as we now pass a list of supertypes to check for
	//{
	//	
	//}
	bool matchingSupertype = false;
	for (auto& st : supertypes)
	{
		if (card.supertype == st)
		{
			matchingSupertype = true;
			break;
		}
	}

	if (matchingSupertype)
	{
		//Continue
	}
	else
	{
		return false;
	}

	//Mana Cost
	if (cardData.HasMember("manaCost"))
	{
		if (!cardData["manaCost"].IsString()) { return false; }
		std::string manaCost = cardData["manaCost"].GetString();

		//Loop through string
		for (int i = 0; i < static_cast<int>(manaCost.size()); ++i)
		{
			//If char == WUBRGC
			if (manaCost[i] == 'W')
			{
				//Increment WUBRGC of cost
				++card.manaCost.white;
			}
			else if (manaCost[i] == 'U')
			{
				++card.manaCost.blue;
			}
			else if (manaCost[i] == 'B')
			{
				++card.manaCost.black;
			}
			else if (manaCost[i] == 'R')
			{
				++card.manaCost.red;
			}
			else if (manaCost[i] == 'G')
			{
				++card.manaCost.green;
			}
			else if (manaCost[i] == 'C')
			{
				++card.manaCost.colourless;
			}
			else if (manaCost[i] == 'X' || manaCost[i] == 'x')
			{
				++card.manaCost.X;
			}
			else if (manaCost[i] != '{' && manaCost[i] != '}')
			{
				//Must be a number
				//Get number between { }
				std::string numberSubString = manaCost.substr(static_cast<size_t>(i), manaCost.find('}', static_cast<size_t>(i)) - 1);
				//Turn to int and store
				card.manaCost.generic = std::stoi(numberSubString);
			}
		}
	}
	//CMC (Converted Mana Cost)
	if (!cardData.HasMember("convertedManaCost")) { return false; }
	if (!cardData["convertedManaCost"].IsNumber()) { return false; }
	card.CMC = cardData["convertedManaCost"].GetFloat();

	

	//Subtype
	if (cardData.HasMember("subtypes"))
	{
		if (!cardData["subtypes"].IsArray()) { return false; }

		//Store strings to add to set data
		std::string primarySubtype;
		std::vector<std::string> secondaries;

		for (rapidjson::SizeType i = 0; i < cardData["subtypes"].Size(); i++)
		{
			if (!cardData["subtypes"][i].IsString()) { return false; }
			card.subtypes.push_back(cardData["subtypes"][i].GetString());
		}	
	}

	//Power & Toughness
	if (cardData.HasMember("power"))
	{
		if (!cardData["power"].IsString()) { return false; };
		std::string power = cardData["power"].GetString();
		for (int i = 0; i < static_cast<int>(power.size()); ++i)
		{
			if (power[i] != '"')
			{
				//Get data between { }
				std::string numberSubString = power.substr(static_cast<size_t>(i), power.find('"', static_cast<size_t>(i)) - 1);

				//Check if numberSubString is a number(non number P&T exist)
				for (int j = 0; j < static_cast<int>(numberSubString.size()); ++j)
				{
					if (!std::isdigit(numberSubString[j]))
					{
						card.standardPower = false;
						card.nonStandardPower = numberSubString;
					}
				}

				//Turn to int and store
				if (card.standardPower)
				{
					card.power = std::stoi(numberSubString);
				}
				break;
			}
		}
	}

	if (cardData.HasMember("toughness"))
	{
		if (!cardData["toughness"].IsString()) { return false; };
		std::string toughness = cardData["toughness"].GetString();
		for (int i = 0; i < static_cast<int>(toughness.size()); ++i)
		{
			if (toughness[i] != '"')
			{
				//Must be a number
				//Get number between { }
				std::string numberSubString = toughness.substr(static_cast<size_t>(i), toughness.find('"', static_cast<size_t>(i)) - 1);

				//Make sure numberSubString is a number(non number P&T exist and are not currently handled)
				for (int j = 0; j < static_cast<int>(numberSubString.size()); ++j)
				{
					if (!std::isdigit(numberSubString[j]))
					{
						card.standardToughness = false;
						card.nonStandardToughness = numberSubString;
					}
				}

				//Turn to int and store
				if (card.standardToughness)
				{
					card.toughness = std::stoi(numberSubString);
				}
				break;
			}
		}
	}

	//Card Text
	if (cardData.HasMember("text"))
	{
		if (!cardData["text"].IsString()) { return false; }
		card.cardText = cardData["text"].GetString();
	}
	else
	{
		card.cardText = "";
	}

	//Keywords
	if (cardData.HasMember("keywords"))
	{
		if (!cardData["keywords"].IsArray()) { return false; }

		//Get keywords
		for (rapidjson::SizeType i = 0; i < cardData["keywords"].Size(); i++)
		{
			//Get keyword
			if (!cardData["keywords"][i].IsString()) { return false; }
			std::string keyword = cardData["keywords"][i].GetString();
			if (keyword == "Flashback")
			{
				int x = 0;
			}
			card.keywords.push_back(keyword);
		}
	}

	return true;
}

bool SetParser::storeCardDataInSetData(MTGStruct::Card* card, SetData* setData)
{
	if (card == nullptr || setData == nullptr)
	{
		return false;
	}

	//Get data from card
	bool W = false; bool U = false; bool B = false; bool R = false; bool G = false;
	MTGStruct::PartsFromColourIdentity(W, U, B, R, G, card->colourIdentity);
	MTGStruct::Rarity rarity = card->rarity;
	
	//--Store Data in Set Data--
	//ColourIdentity
	setData->addColourIdentity(card->colourIdentity);

	//Subtypes
	std::string primarySubtype;
	std::vector<std::string> secondaries;
	for (std::vector<std::string>::iterator it = card->subtypes.begin(); it != card->subtypes.end(); ++it)
	{
		if (it == card->subtypes.begin())
		{
			primarySubtype = *it;
		}
		else
		{
			secondaries.push_back(*it);
		}
	}
	setData->addSubtypes(primarySubtype, secondaries, W, U, B, R, G, rarity);

	//Keywords
	for (auto & k : card->keywords)
	{
		setData->addKeyword(k, W, U, B, R, G, rarity, primarySubtype);
	}

	return true;
}

std::string SetParser::loadJSON(const char* filepath)
{
	std::string rawJSON;
	std::ifstream fStream(filepath, std::ios::in);
	if (fStream.is_open())
	{
		while (!fStream.eof())
		{
			std::getline(fStream, rawJSON);
		}
		fStream.close();
	}
	else
	{
		cerr << "Could not open \"" << filepath << "\"" << " for input\n";
	}

	return rawJSON;
}
