Hi, this was my first game jam so it's a little rough.

Objective: Pick up the baby bird and take it home to the bird box

Controls: 	WASD - Move
			Spacebar - Jump
			E - Pickup/Drop the baby bird
			Alt+F4 - Quit :)